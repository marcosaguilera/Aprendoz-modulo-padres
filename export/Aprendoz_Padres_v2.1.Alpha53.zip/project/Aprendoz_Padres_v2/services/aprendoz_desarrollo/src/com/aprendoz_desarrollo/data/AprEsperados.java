
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprEsperados
 *  10/02/2014 07:48:24
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
