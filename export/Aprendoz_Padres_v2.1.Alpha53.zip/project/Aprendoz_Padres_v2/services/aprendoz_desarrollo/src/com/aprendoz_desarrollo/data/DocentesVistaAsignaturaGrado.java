
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaAsignaturaGrado
 *  10/02/2014 07:48:24
 * 
 */
public class DocentesVistaAsignaturaGrado {

    private DocentesVistaAsignaturaGradoId id;

    public DocentesVistaAsignaturaGradoId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturaGradoId id) {
        this.id = id;
    }

}
