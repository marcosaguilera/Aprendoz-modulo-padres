
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DirectoresDocentesListadoReportes
 *  10/02/2014 07:48:24
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
