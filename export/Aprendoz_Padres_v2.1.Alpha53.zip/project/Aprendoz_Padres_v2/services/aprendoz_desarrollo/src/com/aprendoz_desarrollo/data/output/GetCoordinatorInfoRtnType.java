
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getCoordinatorInfo" on 10/02/2014 07:48:56
 * 
 */
public class GetCoordinatorInfoRtnType {

    private String sy;
    private Integer id;
    private Integer cursoid;
    private String curso;
    private Integer docente_curso;
    private Integer idasignatura;
    private String asignatura;
    private String n1;
    private String n2;
    private String a1;
    private String a2;
    private String correo;

    public String getSy() {
        return sy;
    }

    public void setSy(String sy) {
        this.sy = sy;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCursoid() {
        return cursoid;
    }

    public void setCursoid(Integer cursoid) {
        this.cursoid = cursoid;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Integer getDocente_curso() {
        return docente_curso;
    }

    public void setDocente_curso(Integer docente_curso) {
        this.docente_curso = docente_curso;
    }

    public Integer getIdasignatura() {
        return idasignatura;
    }

    public void setIdasignatura(Integer idasignatura) {
        this.idasignatura = idasignatura;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }

    public String getA1() {
        return a1;
    }

    public void setA1(String a1) {
        this.a1 = a1;
    }

    public String getA2() {
        return a2;
    }

    public void setA2(String a2) {
        this.a2 = a2;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

}
