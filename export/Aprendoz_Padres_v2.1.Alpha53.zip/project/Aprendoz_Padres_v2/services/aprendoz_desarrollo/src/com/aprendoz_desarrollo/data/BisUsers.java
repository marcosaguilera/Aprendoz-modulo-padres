
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.BisUsers
 *  10/02/2014 07:48:25
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}
