
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscAlumAsigCurso
 *  10/02/2014 07:48:25
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
