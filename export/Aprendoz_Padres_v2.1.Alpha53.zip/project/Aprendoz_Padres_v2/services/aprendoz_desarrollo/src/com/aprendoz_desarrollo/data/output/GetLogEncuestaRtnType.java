
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getLogEncuesta" on 10/02/2014 07:48:56
 * 
 */
public class GetLogEncuestaRtnType {

    private Byte terminado;

    public Byte getTerminado() {
        return terminado;
    }

    public void setTerminado(Byte terminado) {
        this.terminado = terminado;
    }

}
