
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Meses
 *  10/02/2014 07:48:24
 * 
 */
public class Meses {

    private Integer id;
    private String mes;
    private String mesnumero;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public String getMesnumero() {
        return mesnumero;
    }

    public void setMesnumero(String mesnumero) {
        this.mesnumero = mesnumero;
    }

}
