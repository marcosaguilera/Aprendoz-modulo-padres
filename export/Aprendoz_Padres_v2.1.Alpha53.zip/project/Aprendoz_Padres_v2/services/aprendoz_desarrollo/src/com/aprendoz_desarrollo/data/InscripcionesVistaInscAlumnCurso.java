
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscripcionesVistaInscAlumnCurso
 *  10/02/2014 07:48:24
 * 
 */
public class InscripcionesVistaInscAlumnCurso {

    private InscripcionesVistaInscAlumnCursoId id;

    public InscripcionesVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
