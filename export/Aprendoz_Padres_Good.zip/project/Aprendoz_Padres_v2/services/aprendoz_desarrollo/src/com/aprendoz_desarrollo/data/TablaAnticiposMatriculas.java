
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TablaAnticiposMatriculas
 *  09/25/2014 15:43:06
 * 
 */
public class TablaAnticiposMatriculas {

    private TablaAnticiposMatriculasId id;

    public TablaAnticiposMatriculasId getId() {
        return id;
    }

    public void setId(TablaAnticiposMatriculasId id) {
        this.id = id;
    }

}
