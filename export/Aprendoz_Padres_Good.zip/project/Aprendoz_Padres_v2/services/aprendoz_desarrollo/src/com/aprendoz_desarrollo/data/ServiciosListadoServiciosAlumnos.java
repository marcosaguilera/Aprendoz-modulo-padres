
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ServiciosListadoServiciosAlumnos
 *  09/25/2014 15:43:06
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
