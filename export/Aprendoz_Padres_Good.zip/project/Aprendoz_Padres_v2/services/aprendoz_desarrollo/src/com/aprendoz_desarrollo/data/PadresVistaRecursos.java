
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaRecursos
 *  09/25/2014 15:43:06
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
