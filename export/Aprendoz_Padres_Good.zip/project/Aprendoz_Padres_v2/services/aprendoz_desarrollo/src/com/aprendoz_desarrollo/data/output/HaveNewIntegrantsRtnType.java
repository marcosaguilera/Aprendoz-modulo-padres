
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "haveNewIntegrants" on 10/01/2014 08:02:57
 * 
 */
public class HaveNewIntegrantsRtnType {

    private Long numero;

    public Long getNumero() {
        return numero;
    }

    public void setNumero(Long numero) {
        this.numero = numero;
    }

}
