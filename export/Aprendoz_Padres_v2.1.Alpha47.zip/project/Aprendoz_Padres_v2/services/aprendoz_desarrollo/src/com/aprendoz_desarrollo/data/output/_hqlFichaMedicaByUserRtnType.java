
package com.aprendoz_desarrollo.data.output;

import java.util.Date;


/**
 * Generated for query "_hqlFichaMedicaByUser" on 09/25/2014 15:43:27
 * 
 */
public class _hqlFichaMedicaByUserRtnType {

    private Integer id;
    private String nombrecompleto;
    private Date fecha;
    private String grado;
    private String rh;
    private String eps;
    private String prepagada;
    private String telefono;
    private String emergencia;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombrecompleto() {
        return nombrecompleto;
    }

    public void setNombrecompleto(String nombrecompleto) {
        this.nombrecompleto = nombrecompleto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

    public String getRh() {
        return rh;
    }

    public void setRh(String rh) {
        this.rh = rh;
    }

    public String getEps() {
        return eps;
    }

    public void setEps(String eps) {
        this.eps = eps;
    }

    public String getPrepagada() {
        return prepagada;
    }

    public void setPrepagada(String prepagada) {
        this.prepagada = prepagada;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmergencia() {
        return emergencia;
    }

    public void setEmergencia(String emergencia) {
        this.emergencia = emergencia;
    }

}
