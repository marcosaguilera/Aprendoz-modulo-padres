
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TablaSaldosMatriculas
 *  09/25/2014 15:43:06
 * 
 */
public class TablaSaldosMatriculas {

    private TablaSaldosMatriculasId id;

    public TablaSaldosMatriculasId getId() {
        return id;
    }

    public void setId(TablaSaldosMatriculasId id) {
        this.id = id;
    }

}
