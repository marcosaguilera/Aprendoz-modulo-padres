
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEstCopy
 *  09/25/2014 15:43:06
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
