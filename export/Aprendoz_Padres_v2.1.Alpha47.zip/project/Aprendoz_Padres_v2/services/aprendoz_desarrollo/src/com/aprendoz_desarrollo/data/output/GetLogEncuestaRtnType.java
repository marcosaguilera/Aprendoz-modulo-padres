
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getLogEncuesta" on 09/25/2014 15:43:27
 * 
 */
public class GetLogEncuestaRtnType {

    private Byte terminado;

    public Byte getTerminado() {
        return terminado;
    }

    public void setTerminado(Byte terminado) {
        this.terminado = terminado;
    }

}
