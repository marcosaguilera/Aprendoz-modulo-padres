
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PersonaEdad
 *  09/25/2014 15:43:05
 * 
 */
public class PersonaEdad {

    private PersonaEdadId id;

    public PersonaEdadId getId() {
        return id;
    }

    public void setId(PersonaEdadId id) {
        this.id = id;
    }

}
