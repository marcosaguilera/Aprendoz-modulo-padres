
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getEducomECR" on 09/25/2014 15:43:27
 * 
 */
public class GetEducomECRRtnType {

    private Integer idpersona;
    private Integer idsy;
    private String educom;

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public Integer getIdsy() {
        return idsy;
    }

    public void setIdsy(Integer idsy) {
        this.idsy = idsy;
    }

    public String getEducom() {
        return educom;
    }

    public void setEducom(String educom) {
        this.educom = educom;
    }

}
