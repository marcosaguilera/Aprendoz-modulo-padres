
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DirectoresDocentesListadoReportes
 *  01/24/2014 18:46:14
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
