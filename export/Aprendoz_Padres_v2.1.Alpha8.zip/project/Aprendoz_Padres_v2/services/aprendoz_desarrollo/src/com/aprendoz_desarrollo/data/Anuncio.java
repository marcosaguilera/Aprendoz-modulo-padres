
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Anuncio
 *  01/24/2014 18:46:15
 * 
 */
public class Anuncio {

    private String anuncio;

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
