
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaActividades
 *  01/24/2014 18:46:14
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
