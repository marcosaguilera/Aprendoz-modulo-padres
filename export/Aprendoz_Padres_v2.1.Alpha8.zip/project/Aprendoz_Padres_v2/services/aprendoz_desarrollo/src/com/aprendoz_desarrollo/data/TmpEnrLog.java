
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TmpEnrLog
 *  01/24/2014 18:46:14
 * 
 */
public class TmpEnrLog {

    private TmpEnrLogId id;

    public TmpEnrLogId getId() {
        return id;
    }

    public void setId(TmpEnrLogId id) {
        this.id = id;
    }

}
