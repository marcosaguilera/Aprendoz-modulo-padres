
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaAsignaturas
 *  01/24/2014 18:46:14
 * 
 */
public class AdministracionVistaAsignaturas {

    private AdministracionVistaAsignaturasId id;

    public AdministracionVistaAsignaturasId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

}
