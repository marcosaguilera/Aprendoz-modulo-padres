
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaInscAlumnCurso
 *  01/24/2014 18:46:14
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}
