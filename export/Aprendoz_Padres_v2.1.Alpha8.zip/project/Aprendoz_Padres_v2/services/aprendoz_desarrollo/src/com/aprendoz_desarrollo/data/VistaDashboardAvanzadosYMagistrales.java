
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaDashboardAvanzadosYMagistrales
 *  01/24/2014 18:46:14
 * 
 */
public class VistaDashboardAvanzadosYMagistrales {

    private VistaDashboardAvanzadosYMagistralesId id;

    public VistaDashboardAvanzadosYMagistralesId getId() {
        return id;
    }

    public void setId(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

}
