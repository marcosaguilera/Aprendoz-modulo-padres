
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaEnvioCorreo
 *  01/24/2014 18:46:14
 * 
 */
public class VistaEnvioCorreo {

    private VistaEnvioCorreoId id;

    public VistaEnvioCorreoId getId() {
        return id;
    }

    public void setId(VistaEnvioCorreoId id) {
        this.id = id;
    }

}
