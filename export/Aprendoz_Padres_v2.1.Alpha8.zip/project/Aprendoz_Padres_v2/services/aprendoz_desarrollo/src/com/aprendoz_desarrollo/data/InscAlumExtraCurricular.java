
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscAlumExtraCurricular
 *  01/24/2014 18:46:14
 * 
 */
public class InscAlumExtraCurricular {

    private Integer inscAlumExtraCurricularId;

    public Integer getInscAlumExtraCurricularId() {
        return inscAlumExtraCurricularId;
    }

    public void setInscAlumExtraCurricularId(Integer inscAlumExtraCurricularId) {
        this.inscAlumExtraCurricularId = inscAlumExtraCurricularId;
    }

}
