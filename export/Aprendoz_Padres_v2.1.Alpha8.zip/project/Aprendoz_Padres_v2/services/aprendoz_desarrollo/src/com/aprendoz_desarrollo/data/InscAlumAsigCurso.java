
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscAlumAsigCurso
 *  01/24/2014 18:46:14
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
