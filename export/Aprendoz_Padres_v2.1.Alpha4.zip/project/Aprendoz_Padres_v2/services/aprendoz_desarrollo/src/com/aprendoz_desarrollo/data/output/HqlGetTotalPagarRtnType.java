
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hqlGetTotalPagar" on 01/24/2014 16:05:13
 * 
 */
public class HqlGetTotalPagarRtnType {

    private Double totalPagar;

    public Double getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(Double totalPagar) {
        this.totalPagar = totalPagar;
    }

}
