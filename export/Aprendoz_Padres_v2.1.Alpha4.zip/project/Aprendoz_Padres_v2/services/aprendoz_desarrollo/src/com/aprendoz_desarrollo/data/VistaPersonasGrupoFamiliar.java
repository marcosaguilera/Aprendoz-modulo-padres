
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaPersonasGrupoFamiliar
 *  01/24/2014 14:18:37
 * 
 */
public class VistaPersonasGrupoFamiliar {

    private VistaPersonasGrupoFamiliarId id;

    public VistaPersonasGrupoFamiliarId getId() {
        return id;
    }

    public void setId(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

}
