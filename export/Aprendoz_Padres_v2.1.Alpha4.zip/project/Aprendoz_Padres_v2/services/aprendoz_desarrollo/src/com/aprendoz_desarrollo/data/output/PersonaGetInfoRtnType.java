
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "personaGetInfo" on 01/24/2014 16:05:13
 * 
 */
public class PersonaGetInfoRtnType {

    private Integer idpersona;
    private String tipoDocumento;
    private String numeroDocumento;
    private String n1;
    private String n2;
    private String a1;
    private String a2;
    private String usuario;
    private String sexo1;
    private String tipoPe;
    private Integer tipoId;
    private Integer idFamilia;
    private String grupoFamilia;
    private Integer idpersona2;
    private String documento;

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }

    public String getA1() {
        return a1;
    }

    public void setA1(String a1) {
        this.a1 = a1;
    }

    public String getA2() {
        return a2;
    }

    public void setA2(String a2) {
        this.a2 = a2;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSexo1() {
        return sexo1;
    }

    public void setSexo1(String sexo1) {
        this.sexo1 = sexo1;
    }

    public String getTipoPe() {
        return tipoPe;
    }

    public void setTipoPe(String tipoPe) {
        this.tipoPe = tipoPe;
    }

    public Integer getTipoId() {
        return tipoId;
    }

    public void setTipoId(Integer tipoId) {
        this.tipoId = tipoId;
    }

    public Integer getIdFamilia() {
        return idFamilia;
    }

    public void setIdFamilia(Integer idFamilia) {
        this.idFamilia = idFamilia;
    }

    public String getGrupoFamilia() {
        return grupoFamilia;
    }

    public void setGrupoFamilia(String grupoFamilia) {
        this.grupoFamilia = grupoFamilia;
    }

    public Integer getIdpersona2() {
        return idpersona2;
    }

    public void setIdpersona2(Integer idpersona2) {
        this.idpersona2 = idpersona2;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

}
