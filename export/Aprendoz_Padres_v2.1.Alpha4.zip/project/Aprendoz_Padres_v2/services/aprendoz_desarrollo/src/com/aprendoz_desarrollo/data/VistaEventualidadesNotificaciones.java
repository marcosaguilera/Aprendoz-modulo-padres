
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaEventualidadesNotificaciones
 *  01/24/2014 14:18:37
 * 
 */
public class VistaEventualidadesNotificaciones {

    private VistaEventualidadesNotificacionesId id;

    public VistaEventualidadesNotificacionesId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesId id) {
        this.id = id;
    }

}
