
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscripcionesVistaInscAlumnCurso
 *  01/24/2014 14:18:37
 * 
 */
public class InscripcionesVistaInscAlumnCurso {

    private InscripcionesVistaInscAlumnCursoId id;

    public InscripcionesVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
