
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaAprendizajes
 *  01/24/2014 14:18:38
 * 
 */
public class PadresVistaAprendizajes {

    private PadresVistaAprendizajesId id;

    public PadresVistaAprendizajesId getId() {
        return id;
    }

    public void setId(PadresVistaAprendizajesId id) {
        this.id = id;
    }

}
