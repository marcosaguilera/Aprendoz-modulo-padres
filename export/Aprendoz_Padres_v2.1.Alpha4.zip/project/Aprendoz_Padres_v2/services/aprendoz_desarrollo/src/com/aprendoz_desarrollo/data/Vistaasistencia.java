
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Vistaasistencia
 *  01/24/2014 14:18:37
 * 
 */
public class Vistaasistencia {

    private VistaasistenciaId id;

    public VistaasistenciaId getId() {
        return id;
    }

    public void setId(VistaasistenciaId id) {
        this.id = id;
    }

}
