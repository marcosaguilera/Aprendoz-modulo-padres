
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaTransporteListadoAlumnos
 *  09/20/2012 08:52:53
 * 
 */
public class VistaTransporteListadoAlumnos {

    private VistaTransporteListadoAlumnosId id;

    public VistaTransporteListadoAlumnos() {
    }

    public VistaTransporteListadoAlumnos(VistaTransporteListadoAlumnosId id) {
        this.id = id;
    }

    public VistaTransporteListadoAlumnosId getId() {
        return id;
    }

    public void setId(VistaTransporteListadoAlumnosId id) {
        this.id = id;
    }

}
