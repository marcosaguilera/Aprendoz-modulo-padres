
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEst
 *  01/24/2014 14:18:37
 * 
 */
public class CalifEst {

    private CalifEstId id;

    public CalifEstId getId() {
        return id;
    }

    public void setId(CalifEstId id) {
        this.id = id;
    }

}
