
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TmpBoletin20122013
 *  01/24/2014 14:18:37
 * 
 */
public class TmpBoletin20122013 {

    private TmpBoletin20122013Id id;

    public TmpBoletin20122013Id getId() {
        return id;
    }

    public void setId(TmpBoletin20122013Id id) {
        this.id = id;
    }

}
