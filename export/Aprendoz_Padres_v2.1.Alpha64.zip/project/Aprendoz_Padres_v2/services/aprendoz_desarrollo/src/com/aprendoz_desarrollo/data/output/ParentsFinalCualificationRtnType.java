
package com.aprendoz_desarrollo.data.output;

import java.util.Date;


/**
 * Generated for query "parentsFinalCualification" on 11/07/2014 07:43:20
 * 
 */
public class ParentsFinalCualificationRtnType {

    private Integer idpersona;
    private Integer idaprendizaje;
    private String calificacion;
    private Float puntaje;
    private Date fechaLogro;

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public Integer getIdaprendizaje() {
        return idaprendizaje;
    }

    public void setIdaprendizaje(Integer idaprendizaje) {
        this.idaprendizaje = idaprendizaje;
    }

    public String getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(String calificacion) {
        this.calificacion = calificacion;
    }

    public Float getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(Float puntaje) {
        this.puntaje = puntaje;
    }

    public Date getFechaLogro() {
        return fechaLogro;
    }

    public void setFechaLogro(Date fechaLogro) {
        this.fechaLogro = fechaLogro;
    }

}
