
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TablaAnticiposMatriculas
 *  10/16/2014 12:01:12
 * 
 */
public class TablaAnticiposMatriculas {

    private TablaAnticiposMatriculasId id;

    public TablaAnticiposMatriculasId getId() {
        return id;
    }

    public void setId(TablaAnticiposMatriculasId id) {
        this.id = id;
    }

}
