
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hqlGetTotalPagar" on 11/07/2014 07:43:20
 * 
 */
public class HqlGetTotalPagarRtnType {

    private Double totalPagar;

    public Double getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(Double totalPagar) {
        this.totalPagar = totalPagar;
    }

}
