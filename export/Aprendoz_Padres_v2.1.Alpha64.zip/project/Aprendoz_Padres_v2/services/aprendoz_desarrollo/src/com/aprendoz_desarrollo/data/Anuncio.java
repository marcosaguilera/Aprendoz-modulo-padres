
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Anuncio
 *  10/16/2014 12:01:13
 * 
 */
public class Anuncio {

    private String anuncio;

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
