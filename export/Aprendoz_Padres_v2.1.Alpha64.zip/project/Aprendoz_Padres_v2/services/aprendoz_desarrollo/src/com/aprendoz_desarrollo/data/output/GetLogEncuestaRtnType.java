
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getLogEncuesta" on 11/07/2014 07:43:20
 * 
 */
public class GetLogEncuestaRtnType {

    private Byte terminado;

    public Byte getTerminado() {
        return terminado;
    }

    public void setTerminado(Byte terminado) {
        this.terminado = terminado;
    }

}
