
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PromocionVistaInscAlumnCurso
 *  10/16/2014 12:01:13
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
