
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaPersonas
 *  10/16/2014 12:01:11
 * 
 */
public class PadresVistaPersonas {

    private PadresVistaPersonasId id;

    public PadresVistaPersonasId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasId id) {
        this.id = id;
    }

}
