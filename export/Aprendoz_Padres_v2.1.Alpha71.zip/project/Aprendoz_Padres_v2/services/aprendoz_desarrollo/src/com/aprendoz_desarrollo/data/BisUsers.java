
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.BisUsers
 *  12/04/2014 08:27:12
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}
