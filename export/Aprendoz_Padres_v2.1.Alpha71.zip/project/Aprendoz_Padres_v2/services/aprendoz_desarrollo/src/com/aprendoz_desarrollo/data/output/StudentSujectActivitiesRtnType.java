
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "studentSujectActivities" on 12/04/2014 08:27:20
 * 
 */
public class StudentSujectActivitiesRtnType {

    private Integer id;
    private String title;
    private String start;
    private Long totalActividades;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public Long getTotalActividades() {
        return totalActividades;
    }

    public void setTotalActividades(Long totalActividades) {
        this.totalActividades = totalActividades;
    }

}
