
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ImportacionExtracto
 *  12/04/2014 08:27:12
 * 
 */
public class ImportacionExtracto {

    private ImportacionExtractoId id;

    public ImportacionExtractoId getId() {
        return id;
    }

    public void setId(ImportacionExtractoId id) {
        this.id = id;
    }

}
