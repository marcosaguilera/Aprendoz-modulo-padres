
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresCorreoCoordinador
 *  12/04/2014 08:27:10
 * 
 */
public class PadresCorreoCoordinador {

    private PadresCorreoCoordinadorId id;

    public PadresCorreoCoordinadorId getId() {
        return id;
    }

    public void setId(PadresCorreoCoordinadorId id) {
        this.id = id;
    }

}
