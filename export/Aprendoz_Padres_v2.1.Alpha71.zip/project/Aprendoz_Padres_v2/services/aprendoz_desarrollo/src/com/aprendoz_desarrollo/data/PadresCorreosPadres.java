
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresCorreosPadres
 *  12/04/2014 08:27:11
 * 
 */
public class PadresCorreosPadres {

    private PadresCorreosPadresId id;

    public PadresCorreosPadresId getId() {
        return id;
    }

    public void setId(PadresCorreosPadresId id) {
        this.id = id;
    }

}
