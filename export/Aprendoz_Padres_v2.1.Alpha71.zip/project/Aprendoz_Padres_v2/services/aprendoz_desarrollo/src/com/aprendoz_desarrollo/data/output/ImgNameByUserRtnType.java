
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "imgNameByUser" on 12/04/2014 08:27:20
 * 
 */
public class ImgNameByUserRtnType {

    private Integer id;
    private String user;
    private String imageName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

}
