
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.FacturacionSapiens
 *  12/04/2014 08:27:10
 * 
 */
public class FacturacionSapiens {

    private FacturacionSapiensId id;

    public FacturacionSapiensId getId() {
        return id;
    }

    public void setId(FacturacionSapiensId id) {
        this.id = id;
    }

}
