
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PromocionVistaInscAlumnCurso
 *  12/04/2014 08:27:11
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
