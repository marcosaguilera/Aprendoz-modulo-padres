
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Anuncio
 *  12/04/2014 08:27:12
 * 
 */
public class Anuncio {

    private String anuncio;

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
