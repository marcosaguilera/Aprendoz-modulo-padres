
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEstCopy
 *  12/04/2014 08:27:12
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
