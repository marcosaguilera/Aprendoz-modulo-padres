
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TablaAnticiposMatriculas
 *  12/04/2014 08:27:11
 * 
 */
public class TablaAnticiposMatriculas {

    private TablaAnticiposMatriculasId id;

    public TablaAnticiposMatriculasId getId() {
        return id;
    }

    public void setId(TablaAnticiposMatriculasId id) {
        this.id = id;
    }

}
