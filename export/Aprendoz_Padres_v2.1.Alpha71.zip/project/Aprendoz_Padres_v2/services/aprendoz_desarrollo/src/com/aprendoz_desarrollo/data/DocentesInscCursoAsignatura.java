
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesInscCursoAsignatura
 *  12/04/2014 08:27:12
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}
