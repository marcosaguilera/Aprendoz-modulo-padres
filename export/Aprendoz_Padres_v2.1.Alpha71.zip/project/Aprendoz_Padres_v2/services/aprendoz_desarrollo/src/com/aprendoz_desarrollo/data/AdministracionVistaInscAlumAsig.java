
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaInscAlumAsig
 *  12/04/2014 08:27:09
 * 
 */
public class AdministracionVistaInscAlumAsig {

    private AdministracionVistaInscAlumAsigId id;

    public AdministracionVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumAsigId id) {
        this.id = id;
    }

}
