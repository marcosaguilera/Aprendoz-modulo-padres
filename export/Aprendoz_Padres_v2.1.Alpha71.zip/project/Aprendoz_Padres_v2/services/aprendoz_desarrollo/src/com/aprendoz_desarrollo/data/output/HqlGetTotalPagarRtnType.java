
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hqlGetTotalPagar" on 12/04/2014 08:27:20
 * 
 */
public class HqlGetTotalPagarRtnType {

    private Double totalPagar;

    public Double getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(Double totalPagar) {
        this.totalPagar = totalPagar;
    }

}
