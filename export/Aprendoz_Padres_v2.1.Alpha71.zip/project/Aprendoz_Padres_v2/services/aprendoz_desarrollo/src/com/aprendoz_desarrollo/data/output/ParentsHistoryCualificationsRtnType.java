
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "parentsHistoryCualifications" on 12/04/2014 08:27:20
 * 
 */
public class ParentsHistoryCualificationsRtnType {

    private Integer idpersona;
    private Integer idaprendizaje;
    private String calificacion;
    private Float puntaje;
    private String fechalogro;
    private String fechaingreso;
    private String calificacion2;
    private String comentario;
    private Integer id;

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public Integer getIdaprendizaje() {
        return idaprendizaje;
    }

    public void setIdaprendizaje(Integer idaprendizaje) {
        this.idaprendizaje = idaprendizaje;
    }

    public String getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(String calificacion) {
        this.calificacion = calificacion;
    }

    public Float getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(Float puntaje) {
        this.puntaje = puntaje;
    }

    public String getFechalogro() {
        return fechalogro;
    }

    public void setFechalogro(String fechalogro) {
        this.fechalogro = fechalogro;
    }

    public String getFechaingreso() {
        return fechaingreso;
    }

    public void setFechaingreso(String fechaingreso) {
        this.fechaingreso = fechaingreso;
    }

    public String getCalificacion2() {
        return calificacion2;
    }

    public void setCalificacion2(String calificacion2) {
        this.calificacion2 = calificacion2;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
