
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaAsignaturaGrado
 *  12/04/2014 08:27:09
 * 
 */
public class DocentesVistaAsignaturaGrado {

    private DocentesVistaAsignaturaGradoId id;

    public DocentesVistaAsignaturaGradoId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturaGradoId id) {
        this.id = id;
    }

}
