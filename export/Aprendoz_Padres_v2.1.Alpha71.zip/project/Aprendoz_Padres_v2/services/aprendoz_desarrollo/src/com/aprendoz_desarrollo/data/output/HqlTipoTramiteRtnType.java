
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hqlTipoTramite" on 12/04/2014 08:27:20
 * 
 */
public class HqlTipoTramiteRtnType {

    private Integer idtipo;
    private Integer tipotramite;
    private Integer idtipo2;
    private Boolean requerido;
    private Boolean valordefecto;
    private Boolean apruebasolicita;

    public Integer getIdtipo() {
        return idtipo;
    }

    public void setIdtipo(Integer idtipo) {
        this.idtipo = idtipo;
    }

    public Integer getTipotramite() {
        return tipotramite;
    }

    public void setTipotramite(Integer tipotramite) {
        this.tipotramite = tipotramite;
    }

    public Integer getIdtipo2() {
        return idtipo2;
    }

    public void setIdtipo2(Integer idtipo2) {
        this.idtipo2 = idtipo2;
    }

    public Boolean getRequerido() {
        return requerido;
    }

    public void setRequerido(Boolean requerido) {
        this.requerido = requerido;
    }

    public Boolean getValordefecto() {
        return valordefecto;
    }

    public void setValordefecto(Boolean valordefecto) {
        this.valordefecto = valordefecto;
    }

    public Boolean getApruebasolicita() {
        return apruebasolicita;
    }

    public void setApruebasolicita(Boolean apruebasolicita) {
        this.apruebasolicita = apruebasolicita;
    }

}
