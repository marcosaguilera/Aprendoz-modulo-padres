
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresTramitesTipopersona
 *  12/04/2014 08:27:12
 * 
 */
public class PadresTramitesTipopersona {

    private PadresTramitesTipopersonaId id;

    public PadresTramitesTipopersonaId getId() {
        return id;
    }

    public void setId(PadresTramitesTipopersonaId id) {
        this.id = id;
    }

}
