
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaPersonasPromocion
 *  12/04/2014 08:27:10
 * 
 */
public class PadresVistaPersonasPromocion {

    private PadresVistaPersonasPromocionId id;

    public PadresVistaPersonasPromocionId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasPromocionId id) {
        this.id = id;
    }

}
