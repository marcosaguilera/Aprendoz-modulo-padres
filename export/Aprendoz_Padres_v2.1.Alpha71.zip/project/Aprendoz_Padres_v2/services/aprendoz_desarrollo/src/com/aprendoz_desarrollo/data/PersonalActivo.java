
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PersonalActivo
 *  12/04/2014 08:27:10
 * 
 */
public class PersonalActivo {

    private PersonalActivoId id;

    public PersonalActivoId getId() {
        return id;
    }

    public void setId(PersonalActivoId id) {
        this.id = id;
    }

}
