
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TmpEnrLog
 *  01/31/2014 15:06:10
 * 
 */
public class TmpEnrLog {

    private TmpEnrLogId id;

    public TmpEnrLogId getId() {
        return id;
    }

    public void setId(TmpEnrLogId id) {
        this.id = id;
    }

}
