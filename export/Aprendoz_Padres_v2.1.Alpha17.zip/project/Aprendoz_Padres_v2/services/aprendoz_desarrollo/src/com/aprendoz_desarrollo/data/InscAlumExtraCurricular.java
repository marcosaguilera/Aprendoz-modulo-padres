
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscAlumExtraCurricular
 *  01/31/2014 15:06:10
 * 
 */
public class InscAlumExtraCurricular {

    private Integer inscAlumExtraCurricularId;

    public Integer getInscAlumExtraCurricularId() {
        return inscAlumExtraCurricularId;
    }

    public void setInscAlumExtraCurricularId(Integer inscAlumExtraCurricularId) {
        this.inscAlumExtraCurricularId = inscAlumExtraCurricularId;
    }

}
