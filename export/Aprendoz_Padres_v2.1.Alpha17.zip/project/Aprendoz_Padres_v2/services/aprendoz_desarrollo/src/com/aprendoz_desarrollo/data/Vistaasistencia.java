
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Vistaasistencia
 *  01/31/2014 15:06:10
 * 
 */
public class Vistaasistencia {

    private VistaasistenciaId id;

    public VistaasistenciaId getId() {
        return id;
    }

    public void setId(VistaasistenciaId id) {
        this.id = id;
    }

}
