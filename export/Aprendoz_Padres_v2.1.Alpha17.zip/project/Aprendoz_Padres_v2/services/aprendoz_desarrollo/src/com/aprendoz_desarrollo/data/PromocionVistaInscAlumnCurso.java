
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PromocionVistaInscAlumnCurso
 *  01/31/2014 15:06:10
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
