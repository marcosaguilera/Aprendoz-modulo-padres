
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "_existeFichaMedicaByUser" on 01/31/2014 15:06:27
 * 
 */
public class _existeFichaMedicaByUserRtnType {

    private Integer idpersona;

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

}
