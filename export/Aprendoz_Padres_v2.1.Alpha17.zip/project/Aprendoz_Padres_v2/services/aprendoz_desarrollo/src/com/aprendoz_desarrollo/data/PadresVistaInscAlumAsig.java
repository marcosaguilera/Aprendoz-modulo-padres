
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaInscAlumAsig
 *  01/31/2014 15:06:10
 * 
 */
public class PadresVistaInscAlumAsig {

    private PadresVistaInscAlumAsigId id;

    public PadresVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

}
