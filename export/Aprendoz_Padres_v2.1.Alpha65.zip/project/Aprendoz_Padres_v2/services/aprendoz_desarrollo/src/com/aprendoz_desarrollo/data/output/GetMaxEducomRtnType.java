
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getMaxEducom" on 11/07/2014 07:43:20
 * 
 */
public class GetMaxEducomRtnType {

    private Integer ideducom;
    private Integer cupoMaximo;
    private Integer idpersona;
    private Integer idsy;

    public Integer getIdeducom() {
        return ideducom;
    }

    public void setIdeducom(Integer ideducom) {
        this.ideducom = ideducom;
    }

    public Integer getCupoMaximo() {
        return cupoMaximo;
    }

    public void setCupoMaximo(Integer cupoMaximo) {
        this.cupoMaximo = cupoMaximo;
    }

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public Integer getIdsy() {
        return idsy;
    }

    public void setIdsy(Integer idsy) {
        this.idsy = idsy;
    }

}
