
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaInscAlumAsig
 *  10/16/2014 12:01:13
 * 
 */
public class AdministracionVistaInscAlumAsig {

    private AdministracionVistaInscAlumAsigId id;

    public AdministracionVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumAsigId id) {
        this.id = id;
    }

}
