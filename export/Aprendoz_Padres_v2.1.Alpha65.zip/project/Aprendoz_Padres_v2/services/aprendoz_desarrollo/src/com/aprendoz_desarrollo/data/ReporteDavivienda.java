
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ReporteDavivienda
 *  10/16/2014 12:01:12
 * 
 */
public class ReporteDavivienda {

    private Integer idReporteSapiensDavivienda;
    private String tarjetadav;
    private String numidres;
    private Float valor;
    private String nombres;
    private String nit;
    private String nnombre;
    private String cursoact;

    public Integer getIdReporteSapiensDavivienda() {
        return idReporteSapiensDavivienda;
    }

    public void setIdReporteSapiensDavivienda(Integer idReporteSapiensDavivienda) {
        this.idReporteSapiensDavivienda = idReporteSapiensDavivienda;
    }

    public String getTarjetadav() {
        return tarjetadav;
    }

    public void setTarjetadav(String tarjetadav) {
        this.tarjetadav = tarjetadav;
    }

    public String getNumidres() {
        return numidres;
    }

    public void setNumidres(String numidres) {
        this.numidres = numidres;
    }

    public Float getValor() {
        return valor;
    }

    public void setValor(Float valor) {
        this.valor = valor;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public String getNnombre() {
        return nnombre;
    }

    public void setNnombre(String nnombre) {
        this.nnombre = nnombre;
    }

    public String getCursoact() {
        return cursoact;
    }

    public void setCursoact(String cursoact) {
        this.cursoact = cursoact;
    }

}
