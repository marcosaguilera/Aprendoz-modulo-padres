
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PersonaEdad
 *  10/16/2014 12:01:12
 * 
 */
public class PersonaEdad {

    private PersonaEdadId id;

    public PersonaEdadId getId() {
        return id;
    }

    public void setId(PersonaEdadId id) {
        this.id = id;
    }

}
