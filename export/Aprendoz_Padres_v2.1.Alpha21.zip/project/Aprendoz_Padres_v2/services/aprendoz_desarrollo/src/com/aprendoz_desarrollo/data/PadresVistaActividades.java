
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaActividades
 *  02/04/2014 07:39:36
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
