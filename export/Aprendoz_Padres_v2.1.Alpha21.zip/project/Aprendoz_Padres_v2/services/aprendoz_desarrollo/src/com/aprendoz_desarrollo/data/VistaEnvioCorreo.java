
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaEnvioCorreo
 *  02/04/2014 07:39:37
 * 
 */
public class VistaEnvioCorreo {

    private VistaEnvioCorreoId id;

    public VistaEnvioCorreoId getId() {
        return id;
    }

    public void setId(VistaEnvioCorreoId id) {
        this.id = id;
    }

}
