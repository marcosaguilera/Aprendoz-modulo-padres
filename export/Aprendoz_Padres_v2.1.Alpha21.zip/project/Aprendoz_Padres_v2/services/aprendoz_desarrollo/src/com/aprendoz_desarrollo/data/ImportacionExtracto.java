
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ImportacionExtracto
 *  02/04/2014 07:39:37
 * 
 */
public class ImportacionExtracto {

    private ImportacionExtractoId id;

    public ImportacionExtractoId getId() {
        return id;
    }

    public void setId(ImportacionExtractoId id) {
        this.id = id;
    }

}
