
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaDashboardNoCalificados
 *  02/04/2014 07:39:37
 * 
 */
public class VistaDashboardNoCalificados {

    private VistaDashboardNoCalificadosId id;

    public VistaDashboardNoCalificadosId getId() {
        return id;
    }

    public void setId(VistaDashboardNoCalificadosId id) {
        this.id = id;
    }

}
