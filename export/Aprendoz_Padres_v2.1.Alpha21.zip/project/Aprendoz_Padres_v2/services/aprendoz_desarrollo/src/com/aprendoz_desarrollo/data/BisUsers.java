
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.BisUsers
 *  02/04/2014 07:39:36
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}
