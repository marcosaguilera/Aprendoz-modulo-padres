
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Salon
 *  02/04/2014 07:39:36
 * 
 */
public class Salon {

    private Integer idSalon;
    private String numeroSalon;

    public Integer getIdSalon() {
        return idSalon;
    }

    public void setIdSalon(Integer idSalon) {
        this.idSalon = idSalon;
    }

    public String getNumeroSalon() {
        return numeroSalon;
    }

    public void setNumeroSalon(String numeroSalon) {
        this.numeroSalon = numeroSalon;
    }

}
