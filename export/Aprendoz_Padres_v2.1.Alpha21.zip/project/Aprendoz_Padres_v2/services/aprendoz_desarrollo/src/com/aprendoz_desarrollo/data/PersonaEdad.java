
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PersonaEdad
 *  02/04/2014 07:39:37
 * 
 */
public class PersonaEdad {

    private PersonaEdadId id;

    public PersonaEdadId getId() {
        return id;
    }

    public void setId(PersonaEdadId id) {
        this.id = id;
    }

}
