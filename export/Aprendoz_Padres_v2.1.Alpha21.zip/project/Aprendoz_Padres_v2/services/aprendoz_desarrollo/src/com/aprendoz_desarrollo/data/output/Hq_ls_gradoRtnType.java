
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hq_ls_grado" on 02/04/2014 07:39:57
 * 
 */
public class Hq_ls_gradoRtnType {

    private Integer idgrado;
    private String grado;

    public Integer getIdgrado() {
        return idgrado;
    }

    public void setIdgrado(Integer idgrado) {
        this.idgrado = idgrado;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

}
