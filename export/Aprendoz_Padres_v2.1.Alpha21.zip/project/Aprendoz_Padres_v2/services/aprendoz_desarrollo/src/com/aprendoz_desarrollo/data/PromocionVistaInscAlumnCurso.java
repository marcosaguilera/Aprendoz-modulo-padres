
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PromocionVistaInscAlumnCurso
 *  02/04/2014 07:39:37
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
