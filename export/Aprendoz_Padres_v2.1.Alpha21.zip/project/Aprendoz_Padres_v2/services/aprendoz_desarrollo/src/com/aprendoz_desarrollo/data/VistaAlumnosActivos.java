
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaAlumnosActivos
 *  02/04/2014 07:39:36
 * 
 */
public class VistaAlumnosActivos {

    private VistaAlumnosActivosId id;

    public VistaAlumnosActivosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosId id) {
        this.id = id;
    }

}
