
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaAlumnosActivosPrejardinNuevos
 *  02/04/2014 07:39:37
 * 
 */
public class VistaAlumnosActivosPrejardinNuevos {

    private VistaAlumnosActivosPrejardinNuevosId id;

    public VistaAlumnosActivosPrejardinNuevosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosPrejardinNuevosId id) {
        this.id = id;
    }

}
