
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaDristribucionAlumnosCursos
 *  02/04/2014 07:39:37
 * 
 */
public class DocentesVistaDristribucionAlumnosCursos {

    private DocentesVistaDristribucionAlumnosCursosId id;

    public DocentesVistaDristribucionAlumnosCursosId getId() {
        return id;
    }

    public void setId(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

}
