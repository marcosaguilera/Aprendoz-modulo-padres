
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getIdbyUser" on 02/04/2014 07:39:57
 * 
 */
public class GetIdbyUserRtnType {

    private Integer id;
    private Integer idtipo;
    private String tipo;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdtipo() {
        return idtipo;
    }

    public void setIdtipo(Integer idtipo) {
        this.idtipo = idtipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

}
