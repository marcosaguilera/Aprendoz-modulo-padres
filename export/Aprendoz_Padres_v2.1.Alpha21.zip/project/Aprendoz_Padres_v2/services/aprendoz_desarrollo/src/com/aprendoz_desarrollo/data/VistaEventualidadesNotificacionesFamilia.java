
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaEventualidadesNotificacionesFamilia
 *  02/04/2014 07:39:37
 * 
 */
public class VistaEventualidadesNotificacionesFamilia {

    private VistaEventualidadesNotificacionesFamiliaId id;

    public VistaEventualidadesNotificacionesFamiliaId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesFamiliaId id) {
        this.id = id;
    }

}
