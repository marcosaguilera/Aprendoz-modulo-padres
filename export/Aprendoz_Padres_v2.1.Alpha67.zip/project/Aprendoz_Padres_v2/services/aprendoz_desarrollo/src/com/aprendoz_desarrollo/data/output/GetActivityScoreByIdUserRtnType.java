
package com.aprendoz_desarrollo.data.output;

import java.util.Date;


/**
 * Generated for query "getActivityScoreByIdUser" on 11/24/2014 08:53:42
 * 
 */
public class GetActivityScoreByIdUserRtnType {

    private Boolean logrado;
    private Date fecha;
    private String comentario;
    private Integer idactividad;
    private Integer idpersona;

    public Boolean getLogrado() {
        return logrado;
    }

    public void setLogrado(Boolean logrado) {
        this.logrado = logrado;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Integer getIdactividad() {
        return idactividad;
    }

    public void setIdactividad(Integer idactividad) {
        this.idactividad = idactividad;
    }

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

}
