
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaRecursos
 *  11/24/2014 08:53:35
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
