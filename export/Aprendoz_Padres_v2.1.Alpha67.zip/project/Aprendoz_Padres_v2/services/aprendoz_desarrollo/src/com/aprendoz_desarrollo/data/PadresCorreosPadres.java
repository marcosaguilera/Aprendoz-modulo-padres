
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresCorreosPadres
 *  11/24/2014 08:53:35
 * 
 */
public class PadresCorreosPadres {

    private PadresCorreosPadresId id;

    public PadresCorreosPadresId getId() {
        return id;
    }

    public void setId(PadresCorreosPadresId id) {
        this.id = id;
    }

}
