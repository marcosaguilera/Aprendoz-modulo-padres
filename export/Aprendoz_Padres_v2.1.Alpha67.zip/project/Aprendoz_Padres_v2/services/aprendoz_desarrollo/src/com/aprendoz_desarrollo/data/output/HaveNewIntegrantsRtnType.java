
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "haveNewIntegrants" on 11/24/2014 08:53:42
 * 
 */
public class HaveNewIntegrantsRtnType {

    private Long numero;

    public Long getNumero() {
        return numero;
    }

    public void setNumero(Long numero) {
        this.numero = numero;
    }

}
