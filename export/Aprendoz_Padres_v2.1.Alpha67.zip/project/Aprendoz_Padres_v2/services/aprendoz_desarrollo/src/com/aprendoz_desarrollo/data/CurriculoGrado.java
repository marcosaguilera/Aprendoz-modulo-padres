
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CurriculoGrado
 *  11/24/2014 08:53:33
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}
