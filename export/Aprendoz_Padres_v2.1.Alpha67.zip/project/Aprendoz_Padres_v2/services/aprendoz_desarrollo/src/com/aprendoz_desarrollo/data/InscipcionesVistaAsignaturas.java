
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscipcionesVistaAsignaturas
 *  11/24/2014 08:53:35
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
