
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.FacturacionSapiens
 *  11/24/2014 08:53:35
 * 
 */
public class FacturacionSapiens {

    private FacturacionSapiensId id;

    public FacturacionSapiensId getId() {
        return id;
    }

    public void setId(FacturacionSapiensId id) {
        this.id = id;
    }

}
