
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "_countGrupoFamiliarUpdated" on 11/24/2014 08:53:42
 * 
 */
public class _countGrupoFamiliarUpdatedRtnType {

    private Long _count;

    public Long get_count() {
        return _count;
    }

    public void set_count(Long _count) {
        this._count = _count;
    }

}
