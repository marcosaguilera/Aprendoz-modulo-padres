
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscripcionesVistaInscAlumnCurso
 *  11/24/2014 08:53:35
 * 
 */
public class InscripcionesVistaInscAlumnCurso {

    private InscripcionesVistaInscAlumnCursoId id;

    public InscripcionesVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
