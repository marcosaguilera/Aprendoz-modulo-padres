
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ServiciosListadoServiciosAlumnos
 *  11/24/2014 08:53:35
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
