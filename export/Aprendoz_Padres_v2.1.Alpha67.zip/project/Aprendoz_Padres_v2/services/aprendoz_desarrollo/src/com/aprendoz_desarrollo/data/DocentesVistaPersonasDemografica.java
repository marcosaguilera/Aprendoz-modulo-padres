
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaPersonasDemografica
 *  11/24/2014 08:53:34
 * 
 */
public class DocentesVistaPersonasDemografica {

    private DocentesVistaPersonasDemograficaId id;

    public DocentesVistaPersonasDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

}
