
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaPersonas
 *  11/24/2014 08:53:34
 * 
 */
public class AdministracionVistaPersonas {

    private AdministracionVistaPersonasId id;

    public AdministracionVistaPersonasId getId() {
        return id;
    }

    public void setId(AdministracionVistaPersonasId id) {
        this.id = id;
    }

}
