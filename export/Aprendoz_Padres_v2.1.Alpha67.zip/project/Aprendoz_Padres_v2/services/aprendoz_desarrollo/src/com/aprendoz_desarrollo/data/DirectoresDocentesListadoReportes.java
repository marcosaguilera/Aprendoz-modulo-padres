
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DirectoresDocentesListadoReportes
 *  11/24/2014 08:53:35
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
