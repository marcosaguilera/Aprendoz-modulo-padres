
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaAprendizajesAsignatura
 *  11/24/2014 08:53:34
 * 
 */
public class DocentesVistaAprendizajesAsignatura {

    private DocentesVistaAprendizajesAsignaturaId id;

    public DocentesVistaAprendizajesAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

}
