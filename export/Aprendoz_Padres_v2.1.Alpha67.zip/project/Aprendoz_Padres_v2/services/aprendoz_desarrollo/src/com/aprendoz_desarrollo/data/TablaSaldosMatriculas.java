
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TablaSaldosMatriculas
 *  11/24/2014 08:53:35
 * 
 */
public class TablaSaldosMatriculas {

    private TablaSaldosMatriculasId id;

    public TablaSaldosMatriculasId getId() {
        return id;
    }

    public void setId(TablaSaldosMatriculasId id) {
        this.id = id;
    }

}
