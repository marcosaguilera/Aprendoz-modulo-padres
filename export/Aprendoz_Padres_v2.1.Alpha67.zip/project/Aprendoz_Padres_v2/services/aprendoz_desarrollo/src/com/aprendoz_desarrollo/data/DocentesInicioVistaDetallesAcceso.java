
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesInicioVistaDetallesAcceso
 *  11/24/2014 08:53:35
 * 
 */
public class DocentesInicioVistaDetallesAcceso {

    private DocentesInicioVistaDetallesAccesoId id;

    public DocentesInicioVistaDetallesAccesoId getId() {
        return id;
    }

    public void setId(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

}
