
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaPersonasPromocion
 *  11/24/2014 08:53:35
 * 
 */
public class PadresVistaPersonasPromocion {

    private PadresVistaPersonasPromocionId id;

    public PadresVistaPersonasPromocionId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasPromocionId id) {
        this.id = id;
    }

}
