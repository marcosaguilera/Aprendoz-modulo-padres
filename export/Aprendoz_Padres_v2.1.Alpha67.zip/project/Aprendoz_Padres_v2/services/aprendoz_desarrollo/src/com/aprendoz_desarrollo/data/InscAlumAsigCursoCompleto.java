
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscAlumAsigCursoCompleto
 *  11/24/2014 08:53:35
 * 
 */
public class InscAlumAsigCursoCompleto {

    private InscAlumAsigCursoCompletoId id;

    public InscAlumAsigCursoCompletoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoCompletoId id) {
        this.id = id;
    }

}
