
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaAsignaturas
 *  11/24/2014 08:53:35
 * 
 */
public class DocentesVistaAsignaturas {

    private DocentesVistaAsignaturasId id;

    public DocentesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturasId id) {
        this.id = id;
    }

}
