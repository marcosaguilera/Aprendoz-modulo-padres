
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "returExitsValue" on 11/24/2014 08:53:42
 * 
 */
public class ReturExitsValueRtnType {

    private Long retorno;

    public Long getRetorno() {
        return retorno;
    }

    public void setRetorno(Long retorno) {
        this.retorno = retorno;
    }

}
