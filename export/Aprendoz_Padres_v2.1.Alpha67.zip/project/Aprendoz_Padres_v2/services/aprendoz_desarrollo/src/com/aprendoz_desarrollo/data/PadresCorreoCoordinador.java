
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresCorreoCoordinador
 *  11/24/2014 08:53:35
 * 
 */
public class PadresCorreoCoordinador {

    private PadresCorreoCoordinadorId id;

    public PadresCorreoCoordinadorId getId() {
        return id;
    }

    public void setId(PadresCorreoCoordinadorId id) {
        this.id = id;
    }

}
