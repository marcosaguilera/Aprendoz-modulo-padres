
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaInscAlumnAsigDemografica
 *  11/24/2014 08:53:35
 * 
 */
public class DocentesVistaInscAlumnAsigDemografica {

    private DocentesVistaInscAlumnAsigDemograficaId id;

    public DocentesVistaInscAlumnAsigDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigDemograficaId id) {
        this.id = id;
    }

}
