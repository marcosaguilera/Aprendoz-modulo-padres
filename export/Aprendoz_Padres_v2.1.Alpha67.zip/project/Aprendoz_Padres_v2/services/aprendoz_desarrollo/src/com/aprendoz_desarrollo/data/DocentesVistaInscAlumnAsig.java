
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaInscAlumnAsig
 *  11/24/2014 08:53:36
 * 
 */
public class DocentesVistaInscAlumnAsig {

    private DocentesVistaInscAlumnAsigId id;

    public DocentesVistaInscAlumnAsigId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigId id) {
        this.id = id;
    }

}
