
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaCalifFinal
 *  11/24/2014 08:53:33
 * 
 */
public class PadresVistaCalifFinal {

    private PadresVistaCalifFinalId id;

    public PadresVistaCalifFinalId getId() {
        return id;
    }

    public void setId(PadresVistaCalifFinalId id) {
        this.id = id;
    }

}
