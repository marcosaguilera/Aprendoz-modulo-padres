
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "_countGrupoFamiliarUpdated" on 10/06/2014 12:40:38
 * 
 */
public class _countGrupoFamiliarUpdatedRtnType {

    private Long _count;

    public Long get_count() {
        return _count;
    }

    public void set_count(Long _count) {
        this._count = _count;
    }

}
