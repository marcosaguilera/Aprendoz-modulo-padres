
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TablaSaldosMatriculas
 *  10/02/2014 07:48:24
 * 
 */
public class TablaSaldosMatriculas {

    private TablaSaldosMatriculasId id;

    public TablaSaldosMatriculasId getId() {
        return id;
    }

    public void setId(TablaSaldosMatriculasId id) {
        this.id = id;
    }

}
