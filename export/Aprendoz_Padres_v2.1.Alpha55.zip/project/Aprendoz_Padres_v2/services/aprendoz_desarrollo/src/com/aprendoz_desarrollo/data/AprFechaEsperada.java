
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprFechaEsperada
 *  10/08/2011 12:59:25
 * 
 */
public class AprFechaEsperada {

    private AprFechaEsperadaId id;

    public AprFechaEsperada() {
    }

    public AprFechaEsperada(AprFechaEsperadaId id) {
        this.id = id;
    }

    public AprFechaEsperadaId getId() {
        return id;
    }

    public void setId(AprFechaEsperadaId id) {
        this.id = id;
    }

}
