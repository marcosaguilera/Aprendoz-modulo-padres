
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getLogEncuesta" on 10/06/2014 12:40:38
 * 
 */
public class GetLogEncuestaRtnType {

    private Byte terminado;

    public Byte getTerminado() {
        return terminado;
    }

    public void setTerminado(Byte terminado) {
        this.terminado = terminado;
    }

}
