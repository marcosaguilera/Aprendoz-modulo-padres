
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getEducomEPD" on 10/06/2014 12:40:38
 * 
 */
public class GetEducomEPDRtnType {

    private Integer idpersona;
    private Integer idsy;
    private String educom;

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public Integer getIdsy() {
        return idsy;
    }

    public void setIdsy(Integer idsy) {
        this.idsy = idsy;
    }

    public String getEducom() {
        return educom;
    }

    public void setEducom(String educom) {
        this.educom = educom;
    }

}
