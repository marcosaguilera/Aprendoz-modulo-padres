
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TablaAnticiposMatriculas
 *  10/02/2014 07:48:24
 * 
 */
public class TablaAnticiposMatriculas {

    private TablaAnticiposMatriculasId id;

    public TablaAnticiposMatriculasId getId() {
        return id;
    }

    public void setId(TablaAnticiposMatriculasId id) {
        this.id = id;
    }

}
