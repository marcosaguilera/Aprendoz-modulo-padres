
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hq_ls_grado" on 10/06/2014 12:40:38
 * 
 */
public class Hq_ls_gradoRtnType {

    private Integer idgrado;
    private String grado;

    public Integer getIdgrado() {
        return idgrado;
    }

    public void setIdgrado(Integer idgrado) {
        this.idgrado = idgrado;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

}
