
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TmpBoletin20122013
 *  06/04/2014 16:25:32
 * 
 */
public class TmpBoletin20122013 {

    private TmpBoletin20122013Id id;

    public TmpBoletin20122013Id getId() {
        return id;
    }

    public void setId(TmpBoletin20122013Id id) {
        this.id = id;
    }

}
