
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaAsignaturasCurso
 *  06/04/2014 16:25:33
 * 
 */
public class AdministracionVistaAsignaturasCurso {

    private AdministracionVistaAsignaturasCursoId id;

    public AdministracionVistaAsignaturasCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasCursoId id) {
        this.id = id;
    }

}
