
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprLogrados
 *  06/04/2014 16:25:32
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
