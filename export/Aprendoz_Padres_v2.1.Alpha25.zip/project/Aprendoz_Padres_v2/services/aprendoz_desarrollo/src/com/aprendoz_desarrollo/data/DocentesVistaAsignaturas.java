
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaAsignaturas
 *  06/04/2014 16:25:33
 * 
 */
public class DocentesVistaAsignaturas {

    private DocentesVistaAsignaturasId id;

    public DocentesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturasId id) {
        this.id = id;
    }

}
