
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesInicioVistaDetallesAcceso
 *  06/04/2014 16:25:32
 * 
 */
public class DocentesInicioVistaDetallesAcceso {

    private DocentesInicioVistaDetallesAccesoId id;

    public DocentesInicioVistaDetallesAccesoId getId() {
        return id;
    }

    public void setId(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

}
