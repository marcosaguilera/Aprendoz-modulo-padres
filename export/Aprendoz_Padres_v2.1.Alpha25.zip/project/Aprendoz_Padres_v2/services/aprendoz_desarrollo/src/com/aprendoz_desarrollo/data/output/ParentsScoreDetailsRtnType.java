
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "parentsScoreDetails" on 06/04/2014 16:25:55
 * 
 */
public class ParentsScoreDetailsRtnType {

    private String fechalogro;
    private String fechaingreso;
    private String calificacion;
    private Float puntaje;
    private String comentario;
    private Integer id;

    public String getFechalogro() {
        return fechalogro;
    }

    public void setFechalogro(String fechalogro) {
        this.fechalogro = fechalogro;
    }

    public String getFechaingreso() {
        return fechaingreso;
    }

    public void setFechaingreso(String fechaingreso) {
        this.fechaingreso = fechaingreso;
    }

    public String getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(String calificacion) {
        this.calificacion = calificacion;
    }

    public Float getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(Float puntaje) {
        this.puntaje = puntaje;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
