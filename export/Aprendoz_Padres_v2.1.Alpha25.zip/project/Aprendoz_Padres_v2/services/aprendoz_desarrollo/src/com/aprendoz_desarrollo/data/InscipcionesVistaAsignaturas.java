
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscipcionesVistaAsignaturas
 *  06/04/2014 16:25:32
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
