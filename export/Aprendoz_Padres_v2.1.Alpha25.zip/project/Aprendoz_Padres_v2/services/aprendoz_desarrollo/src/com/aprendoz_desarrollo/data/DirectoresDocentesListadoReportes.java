
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DirectoresDocentesListadoReportes
 *  06/04/2014 16:25:33
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
