
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscAlumExtraCurricular
 *  02/04/2014 07:39:37
 * 
 */
public class InscAlumExtraCurricular {

    private Integer inscAlumExtraCurricularId;

    public Integer getInscAlumExtraCurricularId() {
        return inscAlumExtraCurricularId;
    }

    public void setInscAlumExtraCurricularId(Integer inscAlumExtraCurricularId) {
        this.inscAlumExtraCurricularId = inscAlumExtraCurricularId;
    }

}
