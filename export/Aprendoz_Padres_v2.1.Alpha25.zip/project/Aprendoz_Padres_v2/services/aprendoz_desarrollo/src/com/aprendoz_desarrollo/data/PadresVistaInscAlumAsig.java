
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaInscAlumAsig
 *  06/04/2014 16:25:33
 * 
 */
public class PadresVistaInscAlumAsig {

    private PadresVistaInscAlumAsigId id;

    public PadresVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

}
