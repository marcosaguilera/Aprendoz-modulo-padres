
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ReportesTipoPersona
 *  06/05/2014 15:30:30
 * 
 */
public class ReportesTipoPersona {

    private Integer idreportestipopersona;
    private Reportes reportes;
    private TipoPersona tipoPersona;

    public Integer getIdreportestipopersona() {
        return idreportestipopersona;
    }

    public void setIdreportestipopersona(Integer idreportestipopersona) {
        this.idreportestipopersona = idreportestipopersona;
    }

    public Reportes getReportes() {
        return reportes;
    }

    public void setReportes(Reportes reportes) {
        this.reportes = reportes;
    }

    public TipoPersona getTipoPersona() {
        return tipoPersona;
    }

    public void setTipoPersona(TipoPersona tipoPersona) {
        this.tipoPersona = tipoPersona;
    }

}
