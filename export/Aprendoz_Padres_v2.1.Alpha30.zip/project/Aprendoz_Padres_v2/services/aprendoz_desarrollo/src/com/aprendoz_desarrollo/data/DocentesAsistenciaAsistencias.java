
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesAsistenciaAsistencias
 *  06/05/2014 15:30:30
 * 
 */
public class DocentesAsistenciaAsistencias {

    private DocentesAsistenciaAsistenciasId id;

    public DocentesAsistenciaAsistenciasId getId() {
        return id;
    }

    public void setId(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

}
