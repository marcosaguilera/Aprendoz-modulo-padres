
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getLogEncuesta" on 06/05/2014 15:51:03
 * 
 */
public class GetLogEncuestaRtnType {

    private Boolean terminado;

    public Boolean getTerminado() {
        return terminado;
    }

    public void setTerminado(Boolean terminado) {
        this.terminado = terminado;
    }

}
