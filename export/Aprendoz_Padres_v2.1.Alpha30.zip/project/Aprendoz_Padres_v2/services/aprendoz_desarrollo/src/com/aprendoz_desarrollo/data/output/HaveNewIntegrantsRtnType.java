
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "haveNewIntegrants" on 06/05/2014 15:51:03
 * 
 */
public class HaveNewIntegrantsRtnType {

    private Long numero;

    public Long getNumero() {
        return numero;
    }

    public void setNumero(Long numero) {
        this.numero = numero;
    }

}
