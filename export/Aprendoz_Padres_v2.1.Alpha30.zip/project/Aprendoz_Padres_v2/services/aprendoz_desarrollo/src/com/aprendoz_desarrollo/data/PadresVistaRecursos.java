
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaRecursos
 *  06/05/2014 15:30:29
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
