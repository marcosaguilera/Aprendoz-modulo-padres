
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaActividades
 *  06/05/2014 15:30:30
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
