
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscAlumAsigCurso
 *  06/05/2014 15:30:30
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
