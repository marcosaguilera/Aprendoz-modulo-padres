
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaInscAlumnAsig
 *  06/05/2014 15:30:29
 * 
 */
public class DocentesVistaInscAlumnAsig {

    private DocentesVistaInscAlumnAsigId id;

    public DocentesVistaInscAlumnAsigId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigId id) {
        this.id = id;
    }

}
