
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "_existeFichaMedicaByUser" on 06/05/2014 15:51:03
 * 
 */
public class _existeFichaMedicaByUserRtnType {

    private Integer idpersona;

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

}
