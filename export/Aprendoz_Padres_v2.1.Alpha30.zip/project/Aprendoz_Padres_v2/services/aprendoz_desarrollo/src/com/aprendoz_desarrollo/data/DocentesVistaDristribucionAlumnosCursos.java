
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaDristribucionAlumnosCursos
 *  06/05/2014 15:30:30
 * 
 */
public class DocentesVistaDristribucionAlumnosCursos {

    private DocentesVistaDristribucionAlumnosCursosId id;

    public DocentesVistaDristribucionAlumnosCursosId getId() {
        return id;
    }

    public void setId(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

}
