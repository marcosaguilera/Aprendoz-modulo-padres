
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaInscAlumAsig
 *  06/05/2014 15:30:30
 * 
 */
public class PadresVistaInscAlumAsig {

    private PadresVistaInscAlumAsigId id;

    public PadresVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

}
