
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprLogrados
 *  06/05/2014 15:30:30
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
