
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CafeteriaGartinuras
 *  06/05/2014 15:30:29
 * 
 */
public class CafeteriaGartinuras {

    private Integer idGarnituras;
    private String garnitura;
    private String descripcion;
    private String imageLink;

    public Integer getIdGarnituras() {
        return idGarnituras;
    }

    public void setIdGarnituras(Integer idGarnituras) {
        this.idGarnituras = idGarnituras;
    }

    public String getGarnitura() {
        return garnitura;
    }

    public void setGarnitura(String garnitura) {
        this.garnitura = garnitura;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

}
