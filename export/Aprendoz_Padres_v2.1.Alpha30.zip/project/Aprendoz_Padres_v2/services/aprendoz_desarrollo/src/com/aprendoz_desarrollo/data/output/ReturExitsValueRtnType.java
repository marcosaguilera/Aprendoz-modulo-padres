
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "returExitsValue" on 06/05/2014 15:51:03
 * 
 */
public class ReturExitsValueRtnType {

    private Long retorno;

    public Long getRetorno() {
        return retorno;
    }

    public void setRetorno(Long retorno) {
        this.retorno = retorno;
    }

}
