
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.BisUsers
 *  06/05/2014 15:30:30
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}
