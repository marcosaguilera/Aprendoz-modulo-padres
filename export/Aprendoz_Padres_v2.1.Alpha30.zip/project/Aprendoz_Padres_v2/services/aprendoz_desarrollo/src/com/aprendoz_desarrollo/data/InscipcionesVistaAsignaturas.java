
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscipcionesVistaAsignaturas
 *  06/05/2014 15:30:29
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
