
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaInscAlumAsig
 *  06/05/2014 15:30:30
 * 
 */
public class AdministracionVistaInscAlumAsig {

    private AdministracionVistaInscAlumAsigId id;

    public AdministracionVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumAsigId id) {
        this.id = id;
    }

}
