
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaAsignaturasCurso
 *  06/05/2014 15:30:30
 * 
 */
public class AdministracionVistaAsignaturasCurso {

    private AdministracionVistaAsignaturasCursoId id;

    public AdministracionVistaAsignaturasCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasCursoId id) {
        this.id = id;
    }

}
