
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprEsperados
 *  06/04/2014 16:25:33
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
