
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaPersonas
 *  06/04/2014 16:25:33
 * 
 */
public class PadresVistaPersonas {

    private PadresVistaPersonasId id;

    public PadresVistaPersonasId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasId id) {
        this.id = id;
    }

}
