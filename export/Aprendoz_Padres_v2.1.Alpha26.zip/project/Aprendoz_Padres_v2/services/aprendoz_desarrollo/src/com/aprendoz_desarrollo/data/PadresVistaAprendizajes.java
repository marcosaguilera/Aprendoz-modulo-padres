
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaAprendizajes
 *  06/04/2014 16:25:32
 * 
 */
public class PadresVistaAprendizajes {

    private PadresVistaAprendizajesId id;

    public PadresVistaAprendizajesId getId() {
        return id;
    }

    public void setId(PadresVistaAprendizajesId id) {
        this.id = id;
    }

}
