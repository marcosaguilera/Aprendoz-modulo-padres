
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaCalifFinal
 *  06/04/2014 16:25:32
 * 
 */
public class PadresVistaCalifFinal {

    private PadresVistaCalifFinalId id;

    public PadresVistaCalifFinalId getId() {
        return id;
    }

    public void setId(PadresVistaCalifFinalId id) {
        this.id = id;
    }

}
