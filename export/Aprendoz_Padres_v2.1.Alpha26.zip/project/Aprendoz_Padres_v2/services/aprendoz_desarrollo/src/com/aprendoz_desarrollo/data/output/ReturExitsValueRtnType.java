
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "returExitsValue" on 06/04/2014 16:25:55
 * 
 */
public class ReturExitsValueRtnType {

    private Long retorno;

    public Long getRetorno() {
        return retorno;
    }

    public void setRetorno(Long retorno) {
        this.retorno = retorno;
    }

}
