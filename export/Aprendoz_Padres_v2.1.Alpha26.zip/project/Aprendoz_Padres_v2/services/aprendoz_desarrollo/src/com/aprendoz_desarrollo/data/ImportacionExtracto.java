
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ImportacionExtracto
 *  06/04/2014 16:25:33
 * 
 */
public class ImportacionExtracto {

    private ImportacionExtractoId id;

    public ImportacionExtractoId getId() {
        return id;
    }

    public void setId(ImportacionExtractoId id) {
        this.id = id;
    }

}
