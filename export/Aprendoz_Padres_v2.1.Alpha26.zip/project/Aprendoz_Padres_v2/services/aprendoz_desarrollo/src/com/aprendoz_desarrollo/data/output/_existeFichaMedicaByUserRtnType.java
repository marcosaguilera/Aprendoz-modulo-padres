
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "_existeFichaMedicaByUser" on 06/04/2014 16:25:55
 * 
 */
public class _existeFichaMedicaByUserRtnType {

    private Integer idpersona;

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

}
