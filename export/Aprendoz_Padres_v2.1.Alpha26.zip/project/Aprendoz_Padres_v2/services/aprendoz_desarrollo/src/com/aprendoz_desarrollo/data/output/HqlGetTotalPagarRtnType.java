
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hqlGetTotalPagar" on 06/04/2014 16:25:55
 * 
 */
public class HqlGetTotalPagarRtnType {

    private Double totalPagar;

    public Double getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(Double totalPagar) {
        this.totalPagar = totalPagar;
    }

}
