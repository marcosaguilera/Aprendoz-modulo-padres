
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEst
 *  06/04/2014 16:25:32
 * 
 */
public class CalifEst {

    private CalifEstId id;

    public CalifEstId getId() {
        return id;
    }

    public void setId(CalifEstId id) {
        this.id = id;
    }

}
