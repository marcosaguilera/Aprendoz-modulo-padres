
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ServiciosListadoServiciosAlumnos
 *  10/16/2014 12:01:13
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
