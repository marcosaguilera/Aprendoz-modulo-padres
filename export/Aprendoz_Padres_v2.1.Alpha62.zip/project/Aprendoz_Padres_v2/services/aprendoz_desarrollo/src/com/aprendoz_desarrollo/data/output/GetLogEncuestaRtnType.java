
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getLogEncuesta" on 10/29/2014 07:46:48
 * 
 */
public class GetLogEncuestaRtnType {

    private Byte terminado;

    public Byte getTerminado() {
        return terminado;
    }

    public void setTerminado(Byte terminado) {
        this.terminado = terminado;
    }

}
