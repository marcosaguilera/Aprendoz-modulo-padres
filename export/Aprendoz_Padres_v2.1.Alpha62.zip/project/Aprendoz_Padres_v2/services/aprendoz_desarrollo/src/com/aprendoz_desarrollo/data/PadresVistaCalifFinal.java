
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaCalifFinal
 *  10/16/2014 12:01:12
 * 
 */
public class PadresVistaCalifFinal {

    private PadresVistaCalifFinalId id;

    public PadresVistaCalifFinalId getId() {
        return id;
    }

    public void setId(PadresVistaCalifFinalId id) {
        this.id = id;
    }

}
