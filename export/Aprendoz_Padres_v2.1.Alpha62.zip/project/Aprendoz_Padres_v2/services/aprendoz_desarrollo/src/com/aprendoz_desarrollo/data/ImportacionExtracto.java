
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ImportacionExtracto
 *  10/16/2014 12:01:13
 * 
 */
public class ImportacionExtracto {

    private ImportacionExtractoId id;

    public ImportacionExtractoId getId() {
        return id;
    }

    public void setId(ImportacionExtractoId id) {
        this.id = id;
    }

}
