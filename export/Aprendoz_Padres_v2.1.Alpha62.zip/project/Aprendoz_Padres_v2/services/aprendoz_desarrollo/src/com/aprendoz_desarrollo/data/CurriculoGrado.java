
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CurriculoGrado
 *  10/16/2014 12:01:12
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}
