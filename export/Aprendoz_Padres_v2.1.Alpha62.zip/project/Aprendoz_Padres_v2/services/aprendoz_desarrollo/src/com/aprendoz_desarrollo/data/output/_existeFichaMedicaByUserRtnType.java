
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "_existeFichaMedicaByUser" on 10/29/2014 07:46:48
 * 
 */
public class _existeFichaMedicaByUserRtnType {

    private Integer idpersona;

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

}
