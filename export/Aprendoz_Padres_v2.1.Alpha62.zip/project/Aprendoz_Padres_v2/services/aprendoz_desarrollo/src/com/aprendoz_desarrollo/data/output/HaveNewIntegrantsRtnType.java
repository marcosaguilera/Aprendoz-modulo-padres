
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "haveNewIntegrants" on 10/29/2014 07:46:48
 * 
 */
public class HaveNewIntegrantsRtnType {

    private Long numero;

    public Long getNumero() {
        return numero;
    }

    public void setNumero(Long numero) {
        this.numero = numero;
    }

}
