
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getTipoPersonaByUser" on 10/29/2014 07:46:48
 * 
 */
public class GetTipoPersonaByUserRtnType {

    private String n1;
    private String n2;
    private String a1;
    private String a2;
    private String usuario;
    private String tipoPe;
    private Integer tipoId;

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }

    public String getA1() {
        return a1;
    }

    public void setA1(String a1) {
        this.a1 = a1;
    }

    public String getA2() {
        return a2;
    }

    public void setA2(String a2) {
        this.a2 = a2;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getTipoPe() {
        return tipoPe;
    }

    public void setTipoPe(String tipoPe) {
        this.tipoPe = tipoPe;
    }

    public Integer getTipoId() {
        return tipoId;
    }

    public void setTipoId(Integer tipoId) {
        this.tipoId = tipoId;
    }

}
