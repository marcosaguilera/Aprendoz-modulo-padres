
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "returExitsValue" on 10/29/2014 07:46:48
 * 
 */
public class ReturExitsValueRtnType {

    private Long retorno;

    public Long getRetorno() {
        return retorno;
    }

    public void setRetorno(Long retorno) {
        this.retorno = retorno;
    }

}
