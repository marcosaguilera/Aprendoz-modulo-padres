
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getUserbyIdPersona" on 08/25/2014 17:28:37
 * 
 */
public class GetUserbyIdPersonaRtnType {

    private Integer idp;
    private String user;
    private String nombrecompleto;

    public Integer getIdp() {
        return idp;
    }

    public void setIdp(Integer idp) {
        this.idp = idp;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getNombrecompleto() {
        return nombrecompleto;
    }

    public void setNombrecompleto(String nombrecompleto) {
        this.nombrecompleto = nombrecompleto;
    }

}
