
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprLogrados
 *  06/18/2014 11:04:57
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
