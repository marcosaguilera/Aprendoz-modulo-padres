
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ServiciosListadoServiciosAlumnos
 *  06/18/2014 11:04:56
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
