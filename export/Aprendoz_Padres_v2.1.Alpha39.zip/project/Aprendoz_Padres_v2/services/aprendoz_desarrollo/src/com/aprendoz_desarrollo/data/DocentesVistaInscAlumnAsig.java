
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaInscAlumnAsig
 *  06/18/2014 11:04:56
 * 
 */
public class DocentesVistaInscAlumnAsig {

    private DocentesVistaInscAlumnAsigId id;

    public DocentesVistaInscAlumnAsigId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigId id) {
        this.id = id;
    }

}
