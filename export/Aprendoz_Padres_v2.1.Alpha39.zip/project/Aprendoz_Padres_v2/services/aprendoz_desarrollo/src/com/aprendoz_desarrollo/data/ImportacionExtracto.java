
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ImportacionExtracto
 *  06/18/2014 11:04:58
 * 
 */
public class ImportacionExtracto {

    private ImportacionExtractoId id;

    public ImportacionExtractoId getId() {
        return id;
    }

    public void setId(ImportacionExtractoId id) {
        this.id = id;
    }

}
