
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PersonaEdad
 *  06/18/2014 11:04:57
 * 
 */
public class PersonaEdad {

    private PersonaEdadId id;

    public PersonaEdadId getId() {
        return id;
    }

    public void setId(PersonaEdadId id) {
        this.id = id;
    }

}
