
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hqlAlergiasByUser" on 08/25/2014 17:28:37
 * 
 */
public class HqlAlergiasByUserRtnType {

    private Integer id;
    private String alergias;
    private String recomendaciones;
    private Integer idficha;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAlergias() {
        return alergias;
    }

    public void setAlergias(String alergias) {
        this.alergias = alergias;
    }

    public String getRecomendaciones() {
        return recomendaciones;
    }

    public void setRecomendaciones(String recomendaciones) {
        this.recomendaciones = recomendaciones;
    }

    public Integer getIdficha() {
        return idficha;
    }

    public void setIdficha(Integer idficha) {
        this.idficha = idficha;
    }

}
