
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getLogEncuesta" on 08/25/2014 17:28:36
 * 
 */
public class GetLogEncuestaRtnType {

    private Boolean terminado;

    public Boolean getTerminado() {
        return terminado;
    }

    public void setTerminado(Boolean terminado) {
        this.terminado = terminado;
    }

}
