
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEstCopy
 *  06/18/2014 11:04:56
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
