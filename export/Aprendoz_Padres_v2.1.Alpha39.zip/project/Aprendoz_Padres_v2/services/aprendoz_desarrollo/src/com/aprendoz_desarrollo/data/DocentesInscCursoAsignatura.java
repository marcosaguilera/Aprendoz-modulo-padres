
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesInscCursoAsignatura
 *  06/18/2014 11:04:58
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}
