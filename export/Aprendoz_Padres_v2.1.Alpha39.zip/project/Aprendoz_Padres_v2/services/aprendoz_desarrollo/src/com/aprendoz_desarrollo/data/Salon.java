
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Salon
 *  06/18/2014 11:04:58
 * 
 */
public class Salon {

    private Integer idSalon;
    private String numeroSalon;

    public Integer getIdSalon() {
        return idSalon;
    }

    public void setIdSalon(Integer idSalon) {
        this.idSalon = idSalon;
    }

    public String getNumeroSalon() {
        return numeroSalon;
    }

    public void setNumeroSalon(String numeroSalon) {
        this.numeroSalon = numeroSalon;
    }

}
