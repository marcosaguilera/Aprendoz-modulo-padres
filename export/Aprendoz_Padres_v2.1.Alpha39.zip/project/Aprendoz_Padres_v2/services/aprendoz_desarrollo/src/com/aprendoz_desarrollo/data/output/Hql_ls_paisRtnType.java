
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hql_ls_pais" on 08/25/2014 17:28:36
 * 
 */
public class Hql_ls_paisRtnType {

    private Integer idpais;
    private String pais;

    public Integer getIdpais() {
        return idpais;
    }

    public void setIdpais(Integer idpais) {
        this.idpais = idpais;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

}
