
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesAsistenciaAsistencias
 *  06/18/2014 11:04:58
 * 
 */
public class DocentesAsistenciaAsistencias {

    private DocentesAsistenciaAsistenciasId id;

    public DocentesAsistenciaAsistenciasId getId() {
        return id;
    }

    public void setId(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

}
