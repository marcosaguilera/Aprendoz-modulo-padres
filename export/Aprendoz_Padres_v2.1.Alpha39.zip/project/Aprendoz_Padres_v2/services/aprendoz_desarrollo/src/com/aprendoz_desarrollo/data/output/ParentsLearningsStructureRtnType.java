
package com.aprendoz_desarrollo.data.output;

import java.util.Date;


/**
 * Generated for query "parentsLearningsStructure" on 08/25/2014 17:28:37
 * 
 */
public class ParentsLearningsStructureRtnType {

    private Integer idasignatura;
    private Integer idunidad;
    private String unidad;
    private String unit;
    private Integer numunidad;
    private Integer idsubtopico;
    private String subtopico;
    private Integer numsubtopico;
    private String subtopic;
    private Integer idaprendizaje;
    private String aprendizaje;
    private Date fecha;

    public Integer getIdasignatura() {
        return idasignatura;
    }

    public void setIdasignatura(Integer idasignatura) {
        this.idasignatura = idasignatura;
    }

    public Integer getIdunidad() {
        return idunidad;
    }

    public void setIdunidad(Integer idunidad) {
        this.idunidad = idunidad;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Integer getNumunidad() {
        return numunidad;
    }

    public void setNumunidad(Integer numunidad) {
        this.numunidad = numunidad;
    }

    public Integer getIdsubtopico() {
        return idsubtopico;
    }

    public void setIdsubtopico(Integer idsubtopico) {
        this.idsubtopico = idsubtopico;
    }

    public String getSubtopico() {
        return subtopico;
    }

    public void setSubtopico(String subtopico) {
        this.subtopico = subtopico;
    }

    public Integer getNumsubtopico() {
        return numsubtopico;
    }

    public void setNumsubtopico(Integer numsubtopico) {
        this.numsubtopico = numsubtopico;
    }

    public String getSubtopic() {
        return subtopic;
    }

    public void setSubtopic(String subtopic) {
        this.subtopic = subtopic;
    }

    public Integer getIdaprendizaje() {
        return idaprendizaje;
    }

    public void setIdaprendizaje(Integer idaprendizaje) {
        this.idaprendizaje = idaprendizaje;
    }

    public String getAprendizaje() {
        return aprendizaje;
    }

    public void setAprendizaje(String aprendizaje) {
        this.aprendizaje = aprendizaje;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

}
