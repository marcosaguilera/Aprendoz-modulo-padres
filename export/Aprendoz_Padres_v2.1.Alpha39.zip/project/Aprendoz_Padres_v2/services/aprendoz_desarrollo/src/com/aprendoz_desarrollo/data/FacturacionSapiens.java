
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.FacturacionSapiens
 *  06/18/2014 11:04:57
 * 
 */
public class FacturacionSapiens {

    private FacturacionSapiensId id;

    public FacturacionSapiensId getId() {
        return id;
    }

    public void setId(FacturacionSapiensId id) {
        this.id = id;
    }

}
