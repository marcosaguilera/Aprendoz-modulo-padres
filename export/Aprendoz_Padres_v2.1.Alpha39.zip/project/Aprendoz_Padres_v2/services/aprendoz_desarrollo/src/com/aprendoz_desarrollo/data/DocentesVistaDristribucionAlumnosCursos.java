
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaDristribucionAlumnosCursos
 *  06/18/2014 11:04:57
 * 
 */
public class DocentesVistaDristribucionAlumnosCursos {

    private DocentesVistaDristribucionAlumnosCursosId id;

    public DocentesVistaDristribucionAlumnosCursosId getId() {
        return id;
    }

    public void setId(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

}
