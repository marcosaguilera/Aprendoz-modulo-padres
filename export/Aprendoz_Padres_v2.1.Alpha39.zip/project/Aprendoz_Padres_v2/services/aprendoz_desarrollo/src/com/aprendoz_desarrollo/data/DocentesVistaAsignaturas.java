
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaAsignaturas
 *  06/18/2014 11:04:58
 * 
 */
public class DocentesVistaAsignaturas {

    private DocentesVistaAsignaturasId id;

    public DocentesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturasId id) {
        this.id = id;
    }

}
