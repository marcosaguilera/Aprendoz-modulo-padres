
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.FacturacionSapiens
 *  10/16/2014 12:01:12
 * 
 */
public class FacturacionSapiens {

    private FacturacionSapiensId id;

    public FacturacionSapiensId getId() {
        return id;
    }

    public void setId(FacturacionSapiensId id) {
        this.id = id;
    }

}
