
package com.aprendoz_desarrollo.data.output;

import java.util.Date;


/**
 * Generated for query "detailsActivitiesStudent" on 10/21/2014 15:52:23
 * 
 */
public class DetailsActivitiesStudentRtnType {

    private Integer id;
    private String actividad;
    private Integer idasignatura;
    private String title;
    private Date fecha;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getActividad() {
        return actividad;
    }

    public void setActividad(String actividad) {
        this.actividad = actividad;
    }

    public Integer getIdasignatura() {
        return idasignatura;
    }

    public void setIdasignatura(Integer idasignatura) {
        this.idasignatura = idasignatura;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

}
