
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "returExitsValue" on 10/21/2014 15:52:23
 * 
 */
public class ReturExitsValueRtnType {

    private Long retorno;

    public Long getRetorno() {
        return retorno;
    }

    public void setRetorno(Long retorno) {
        this.retorno = retorno;
    }

}
