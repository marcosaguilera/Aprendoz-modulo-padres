
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaActividades
 *  10/16/2014 12:01:12
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
