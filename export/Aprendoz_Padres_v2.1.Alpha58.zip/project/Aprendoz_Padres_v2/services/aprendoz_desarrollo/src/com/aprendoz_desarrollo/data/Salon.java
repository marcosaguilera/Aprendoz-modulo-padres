
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Salon
 *  10/16/2014 12:01:13
 * 
 */
public class Salon {

    private Integer idSalon;
    private String numeroSalon;

    public Integer getIdSalon() {
        return idSalon;
    }

    public void setIdSalon(Integer idSalon) {
        this.idSalon = idSalon;
    }

    public String getNumeroSalon() {
        return numeroSalon;
    }

    public void setNumeroSalon(String numeroSalon) {
        this.numeroSalon = numeroSalon;
    }

}
