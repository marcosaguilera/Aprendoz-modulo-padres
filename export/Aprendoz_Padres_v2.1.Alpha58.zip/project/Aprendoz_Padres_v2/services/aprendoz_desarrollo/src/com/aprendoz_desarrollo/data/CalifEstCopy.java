
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEstCopy
 *  10/16/2014 12:01:12
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
