
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscAlumAsigCurso
 *  10/16/2014 12:01:12
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
