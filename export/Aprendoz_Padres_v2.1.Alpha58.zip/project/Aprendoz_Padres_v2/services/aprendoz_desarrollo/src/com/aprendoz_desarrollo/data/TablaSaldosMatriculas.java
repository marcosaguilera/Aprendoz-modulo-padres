
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TablaSaldosMatriculas
 *  10/16/2014 12:01:12
 * 
 */
public class TablaSaldosMatriculas {

    private TablaSaldosMatriculasId id;

    public TablaSaldosMatriculasId getId() {
        return id;
    }

    public void setId(TablaSaldosMatriculasId id) {
        this.id = id;
    }

}
