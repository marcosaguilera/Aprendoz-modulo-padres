
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaCalifFinal
 *  01/31/2014 15:06:10
 * 
 */
public class PadresVistaCalifFinal {

    private PadresVistaCalifFinalId id;

    public PadresVistaCalifFinalId getId() {
        return id;
    }

    public void setId(PadresVistaCalifFinalId id) {
        this.id = id;
    }

}
