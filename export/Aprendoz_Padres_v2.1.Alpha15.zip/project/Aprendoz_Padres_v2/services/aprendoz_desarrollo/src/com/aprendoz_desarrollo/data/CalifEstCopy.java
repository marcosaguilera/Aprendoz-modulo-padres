
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEstCopy
 *  01/31/2014 15:06:10
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
