
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaMatriculasGraficasTotalDia
 *  01/31/2014 15:06:10
 * 
 */
public class VistaMatriculasGraficasTotalDia {

    private VistaMatriculasGraficasTotalDiaId id;

    public VistaMatriculasGraficasTotalDiaId getId() {
        return id;
    }

    public void setId(VistaMatriculasGraficasTotalDiaId id) {
        this.id = id;
    }

}
