
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TmpBoletin20122013
 *  01/31/2014 15:06:10
 * 
 */
public class TmpBoletin20122013 {

    private TmpBoletin20122013Id id;

    public TmpBoletin20122013Id getId() {
        return id;
    }

    public void setId(TmpBoletin20122013Id id) {
        this.id = id;
    }

}
