
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaDashboardAvanzadosYMagistrales
 *  01/31/2014 15:06:10
 * 
 */
public class VistaDashboardAvanzadosYMagistrales {

    private VistaDashboardAvanzadosYMagistralesId id;

    public VistaDashboardAvanzadosYMagistralesId getId() {
        return id;
    }

    public void setId(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

}
