
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesAsistenciaAsistencias
 *  01/31/2014 15:06:10
 * 
 */
public class DocentesAsistenciaAsistencias {

    private DocentesAsistenciaAsistenciasId id;

    public DocentesAsistenciaAsistenciasId getId() {
        return id;
    }

    public void setId(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

}
