
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaAlumnosActivosPrejardinNuevos
 *  01/31/2014 15:06:10
 * 
 */
public class VistaAlumnosActivosPrejardinNuevos {

    private VistaAlumnosActivosPrejardinNuevosId id;

    public VistaAlumnosActivosPrejardinNuevosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosPrejardinNuevosId id) {
        this.id = id;
    }

}
