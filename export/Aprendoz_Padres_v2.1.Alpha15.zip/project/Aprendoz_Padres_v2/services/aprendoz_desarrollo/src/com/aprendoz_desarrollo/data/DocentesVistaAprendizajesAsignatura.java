
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaAprendizajesAsignatura
 *  01/31/2014 15:06:10
 * 
 */
public class DocentesVistaAprendizajesAsignatura {

    private DocentesVistaAprendizajesAsignaturaId id;

    public DocentesVistaAprendizajesAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

}
