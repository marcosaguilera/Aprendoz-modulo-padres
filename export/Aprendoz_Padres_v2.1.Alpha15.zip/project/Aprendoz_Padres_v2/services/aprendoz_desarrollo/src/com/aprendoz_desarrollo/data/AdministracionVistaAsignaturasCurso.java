
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaAsignaturasCurso
 *  01/31/2014 15:06:10
 * 
 */
public class AdministracionVistaAsignaturasCurso {

    private AdministracionVistaAsignaturasCursoId id;

    public AdministracionVistaAsignaturasCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasCursoId id) {
        this.id = id;
    }

}
