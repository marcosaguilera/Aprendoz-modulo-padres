
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaEventualidadesNotificacionesFamilia
 *  01/31/2014 15:06:10
 * 
 */
public class VistaEventualidadesNotificacionesFamilia {

    private VistaEventualidadesNotificacionesFamiliaId id;

    public VistaEventualidadesNotificacionesFamiliaId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesFamiliaId id) {
        this.id = id;
    }

}
