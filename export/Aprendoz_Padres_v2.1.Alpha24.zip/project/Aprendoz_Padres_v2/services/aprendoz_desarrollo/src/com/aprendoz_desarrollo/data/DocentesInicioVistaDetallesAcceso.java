
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesInicioVistaDetallesAcceso
 *  04/02/2014 11:03:07
 * 
 */
public class DocentesInicioVistaDetallesAcceso {

    private DocentesInicioVistaDetallesAccesoId id;

    public DocentesInicioVistaDetallesAccesoId getId() {
        return id;
    }

    public void setId(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

}
