
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesAsistenciaAsistencias
 *  04/02/2014 11:03:06
 * 
 */
public class DocentesAsistenciaAsistencias {

    private DocentesAsistenciaAsistenciasId id;

    public DocentesAsistenciaAsistenciasId getId() {
        return id;
    }

    public void setId(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

}
