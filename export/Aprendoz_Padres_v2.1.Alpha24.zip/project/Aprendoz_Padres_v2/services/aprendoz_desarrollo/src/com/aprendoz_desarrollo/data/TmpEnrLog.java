
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TmpEnrLog
 *  04/02/2014 11:03:06
 * 
 */
public class TmpEnrLog {

    private TmpEnrLogId id;

    public TmpEnrLogId getId() {
        return id;
    }

    public void setId(TmpEnrLogId id) {
        this.id = id;
    }

}
