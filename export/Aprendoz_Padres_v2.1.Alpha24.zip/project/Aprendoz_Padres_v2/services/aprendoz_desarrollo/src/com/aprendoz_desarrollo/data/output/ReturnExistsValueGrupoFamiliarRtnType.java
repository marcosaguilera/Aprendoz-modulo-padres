
package com.aprendoz_desarrollo.data.output;

import java.util.Date;


/**
 * Generated for query "returnExistsValueGrupoFamiliar" on 05/06/2014 09:33:50
 * 
 */
public class ReturnExistsValueGrupoFamiliarRtnType {

    private Integer valorRetornado;
    private Date fecha;
    private Byte actualizado;
    private Integer idgrupo;

    public Integer getValorRetornado() {
        return valorRetornado;
    }

    public void setValorRetornado(Integer valorRetornado) {
        this.valorRetornado = valorRetornado;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Byte getActualizado() {
        return actualizado;
    }

    public void setActualizado(Byte actualizado) {
        this.actualizado = actualizado;
    }

    public Integer getIdgrupo() {
        return idgrupo;
    }

    public void setIdgrupo(Integer idgrupo) {
        this.idgrupo = idgrupo;
    }

}
