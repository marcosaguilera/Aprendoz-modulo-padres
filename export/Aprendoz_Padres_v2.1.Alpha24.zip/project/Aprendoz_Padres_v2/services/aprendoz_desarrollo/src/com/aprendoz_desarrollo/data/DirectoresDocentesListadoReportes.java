
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DirectoresDocentesListadoReportes
 *  04/02/2014 11:03:06
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
