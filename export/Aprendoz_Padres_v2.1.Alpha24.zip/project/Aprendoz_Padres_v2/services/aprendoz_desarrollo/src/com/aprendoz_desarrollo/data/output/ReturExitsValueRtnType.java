
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "returExitsValue" on 05/06/2014 09:33:50
 * 
 */
public class ReturExitsValueRtnType {

    private Long retorno;

    public Long getRetorno() {
        return retorno;
    }

    public void setRetorno(Long retorno) {
        this.retorno = retorno;
    }

}
