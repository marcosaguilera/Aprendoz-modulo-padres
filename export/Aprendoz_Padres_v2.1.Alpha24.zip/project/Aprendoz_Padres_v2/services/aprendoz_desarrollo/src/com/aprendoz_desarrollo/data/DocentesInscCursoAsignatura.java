
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesInscCursoAsignatura
 *  04/02/2014 11:03:06
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}
