
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.ServiciosListadoServiciosAlumnos
 *  04/02/2014 11:03:06
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
