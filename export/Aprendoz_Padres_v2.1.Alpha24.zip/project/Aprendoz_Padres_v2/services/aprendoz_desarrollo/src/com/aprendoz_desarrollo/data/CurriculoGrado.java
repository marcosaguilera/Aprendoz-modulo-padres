
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CurriculoGrado
 *  04/02/2014 11:03:06
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}
