
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaAlumnosActivos
 *  04/02/2014 11:03:07
 * 
 */
public class VistaAlumnosActivos {

    private VistaAlumnosActivosId id;

    public VistaAlumnosActivosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosId id) {
        this.id = id;
    }

}
