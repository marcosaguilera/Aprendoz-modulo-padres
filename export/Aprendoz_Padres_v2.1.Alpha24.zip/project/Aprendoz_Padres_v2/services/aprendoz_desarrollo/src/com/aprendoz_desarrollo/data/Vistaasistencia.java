
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Vistaasistencia
 *  04/02/2014 11:03:07
 * 
 */
public class Vistaasistencia {

    private VistaasistenciaId id;

    public VistaasistenciaId getId() {
        return id;
    }

    public void setId(VistaasistenciaId id) {
        this.id = id;
    }

}
