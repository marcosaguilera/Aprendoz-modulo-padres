
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscripcionesVistaInscAlumnCurso
 *  04/02/2014 11:03:06
 * 
 */
public class InscripcionesVistaInscAlumnCurso {

    private InscripcionesVistaInscAlumnCursoId id;

    public InscripcionesVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
