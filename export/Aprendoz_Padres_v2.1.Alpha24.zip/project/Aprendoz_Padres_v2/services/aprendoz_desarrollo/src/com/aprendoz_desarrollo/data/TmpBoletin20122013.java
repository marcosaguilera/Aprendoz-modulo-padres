
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TmpBoletin20122013
 *  04/02/2014 11:03:06
 * 
 */
public class TmpBoletin20122013 {

    private TmpBoletin20122013Id id;

    public TmpBoletin20122013Id getId() {
        return id;
    }

    public void setId(TmpBoletin20122013Id id) {
        this.id = id;
    }

}
