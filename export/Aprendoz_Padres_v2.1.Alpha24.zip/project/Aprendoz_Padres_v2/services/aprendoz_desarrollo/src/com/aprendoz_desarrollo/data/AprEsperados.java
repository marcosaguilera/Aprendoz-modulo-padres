
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprEsperados
 *  04/02/2014 11:03:06
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
