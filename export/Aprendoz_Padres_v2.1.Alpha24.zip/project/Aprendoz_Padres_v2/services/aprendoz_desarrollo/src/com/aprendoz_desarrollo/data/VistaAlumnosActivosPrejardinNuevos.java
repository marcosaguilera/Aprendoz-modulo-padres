
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaAlumnosActivosPrejardinNuevos
 *  04/02/2014 11:03:06
 * 
 */
public class VistaAlumnosActivosPrejardinNuevos {

    private VistaAlumnosActivosPrejardinNuevosId id;

    public VistaAlumnosActivosPrejardinNuevosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosPrejardinNuevosId id) {
        this.id = id;
    }

}
