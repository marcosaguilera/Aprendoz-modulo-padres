
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscAlumAsigCurso
 *  04/02/2014 11:03:06
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
