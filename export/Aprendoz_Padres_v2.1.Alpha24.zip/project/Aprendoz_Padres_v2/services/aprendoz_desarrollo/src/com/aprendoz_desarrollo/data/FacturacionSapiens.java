
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.FacturacionSapiens
 *  04/02/2014 11:03:06
 * 
 */
public class FacturacionSapiens {

    private FacturacionSapiensId id;

    public FacturacionSapiensId getId() {
        return id;
    }

    public void setId(FacturacionSapiensId id) {
        this.id = id;
    }

}
