
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaRecursos
 *  04/02/2014 11:03:06
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
