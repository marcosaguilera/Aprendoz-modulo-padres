
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaInscAlumAsig
 *  04/02/2014 11:03:06
 * 
 */
public class AdministracionVistaInscAlumAsig {

    private AdministracionVistaInscAlumAsigId id;

    public AdministracionVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumAsigId id) {
        this.id = id;
    }

}
