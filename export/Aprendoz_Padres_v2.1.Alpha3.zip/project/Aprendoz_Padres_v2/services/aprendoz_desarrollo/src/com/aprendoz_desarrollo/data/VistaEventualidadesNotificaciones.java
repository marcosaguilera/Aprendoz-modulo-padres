
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaEventualidadesNotificaciones
 *  01/22/2014 15:41:28
 * 
 */
public class VistaEventualidadesNotificaciones {

    private VistaEventualidadesNotificacionesId id;

    public VistaEventualidadesNotificacionesId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesId id) {
        this.id = id;
    }

}
