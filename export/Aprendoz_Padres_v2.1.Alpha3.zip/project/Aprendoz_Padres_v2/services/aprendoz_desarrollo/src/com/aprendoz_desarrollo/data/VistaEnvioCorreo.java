
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaEnvioCorreo
 *  01/22/2014 15:41:29
 * 
 */
public class VistaEnvioCorreo {

    private VistaEnvioCorreoId id;

    public VistaEnvioCorreoId getId() {
        return id;
    }

    public void setId(VistaEnvioCorreoId id) {
        this.id = id;
    }

}
