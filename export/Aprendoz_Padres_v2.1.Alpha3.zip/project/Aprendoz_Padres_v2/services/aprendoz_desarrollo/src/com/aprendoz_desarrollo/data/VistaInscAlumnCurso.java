
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaInscAlumnCurso
 *  01/22/2014 15:41:28
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}
