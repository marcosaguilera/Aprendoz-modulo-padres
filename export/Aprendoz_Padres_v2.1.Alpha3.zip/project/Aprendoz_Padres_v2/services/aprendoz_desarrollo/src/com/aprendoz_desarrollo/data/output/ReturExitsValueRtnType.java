
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "returExitsValue" on 01/23/2014 16:03:19
 * 
 */
public class ReturExitsValueRtnType {

    private Long retorno;

    public Long getRetorno() {
        return retorno;
    }

    public void setRetorno(Long retorno) {
        this.retorno = retorno;
    }

}
