
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaPersonasGrupoFamiliar
 *  01/22/2014 15:41:29
 * 
 */
public class VistaPersonasGrupoFamiliar {

    private VistaPersonasGrupoFamiliarId id;

    public VistaPersonasGrupoFamiliarId getId() {
        return id;
    }

    public void setId(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

}
