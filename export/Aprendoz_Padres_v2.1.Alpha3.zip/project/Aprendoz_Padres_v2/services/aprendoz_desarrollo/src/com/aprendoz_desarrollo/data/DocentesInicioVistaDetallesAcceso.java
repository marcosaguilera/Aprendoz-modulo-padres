
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesInicioVistaDetallesAcceso
 *  01/22/2014 15:41:28
 * 
 */
public class DocentesInicioVistaDetallesAcceso {

    private DocentesInicioVistaDetallesAccesoId id;

    public DocentesInicioVistaDetallesAccesoId getId() {
        return id;
    }

    public void setId(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

}
