
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaAprendizajes
 *  01/22/2014 15:41:28
 * 
 */
public class PadresVistaAprendizajes {

    private PadresVistaAprendizajesId id;

    public PadresVistaAprendizajesId getId() {
        return id;
    }

    public void setId(PadresVistaAprendizajesId id) {
        this.id = id;
    }

}
