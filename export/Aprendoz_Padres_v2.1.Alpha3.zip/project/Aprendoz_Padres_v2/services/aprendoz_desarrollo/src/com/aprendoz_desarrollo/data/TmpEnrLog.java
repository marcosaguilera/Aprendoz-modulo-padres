
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TmpEnrLog
 *  01/22/2014 15:41:28
 * 
 */
public class TmpEnrLog {

    private TmpEnrLogId id;

    public TmpEnrLogId getId() {
        return id;
    }

    public void setId(TmpEnrLogId id) {
        this.id = id;
    }

}
