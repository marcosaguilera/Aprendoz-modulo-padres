
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprLogrados
 *  01/22/2014 15:41:28
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
