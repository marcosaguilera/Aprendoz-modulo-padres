
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaInscAlumnCurso
 *  01/22/2014 15:41:28
 * 
 */
public class AdministracionVistaInscAlumnCurso {

    private AdministracionVistaInscAlumnCursoId id;

    public AdministracionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
