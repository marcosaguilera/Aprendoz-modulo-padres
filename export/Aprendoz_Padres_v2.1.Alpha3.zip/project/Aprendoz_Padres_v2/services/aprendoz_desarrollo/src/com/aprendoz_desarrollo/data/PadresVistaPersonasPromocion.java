
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaPersonasPromocion
 *  01/22/2014 15:41:27
 * 
 */
public class PadresVistaPersonasPromocion {

    private PadresVistaPersonasPromocionId id;

    public PadresVistaPersonasPromocionId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasPromocionId id) {
        this.id = id;
    }

}
