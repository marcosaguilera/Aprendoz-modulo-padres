
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaDashboardAvanzadosYMagistrales
 *  01/22/2014 15:41:28
 * 
 */
public class VistaDashboardAvanzadosYMagistrales {

    private VistaDashboardAvanzadosYMagistralesId id;

    public VistaDashboardAvanzadosYMagistralesId getId() {
        return id;
    }

    public void setId(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

}
