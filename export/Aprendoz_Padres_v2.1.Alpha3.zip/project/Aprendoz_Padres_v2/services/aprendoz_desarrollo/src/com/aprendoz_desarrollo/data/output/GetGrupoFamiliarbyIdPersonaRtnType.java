
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "getGrupoFamiliarbyIdPersona" on 01/23/2014 16:03:19
 * 
 */
public class GetGrupoFamiliarbyIdPersonaRtnType {

    private String user;
    private Integer pid;
    private String nombreCompleto;
    private String tipo;
    private Integer idgrupo;
    private String familia;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Integer getIdgrupo() {
        return idgrupo;
    }

    public void setIdgrupo(Integer idgrupo) {
        this.idgrupo = idgrupo;
    }

    public String getFamilia() {
        return familia;
    }

    public void setFamilia(String familia) {
        this.familia = familia;
    }

}
