
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaPersonas
 *  01/22/2014 15:41:29
 * 
 */
public class PadresVistaPersonas {

    private PadresVistaPersonasId id;

    public PadresVistaPersonasId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasId id) {
        this.id = id;
    }

}
