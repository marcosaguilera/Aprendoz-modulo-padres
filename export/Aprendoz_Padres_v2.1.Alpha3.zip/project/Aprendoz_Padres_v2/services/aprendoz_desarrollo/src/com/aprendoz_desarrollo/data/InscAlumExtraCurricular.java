
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscAlumExtraCurricular
 *  01/22/2014 15:41:27
 * 
 */
public class InscAlumExtraCurricular {

    private Integer inscAlumExtraCurricularId;

    public Integer getInscAlumExtraCurricularId() {
        return inscAlumExtraCurricularId;
    }

    public void setInscAlumExtraCurricularId(Integer inscAlumExtraCurricularId) {
        this.inscAlumExtraCurricularId = inscAlumExtraCurricularId;
    }

}
