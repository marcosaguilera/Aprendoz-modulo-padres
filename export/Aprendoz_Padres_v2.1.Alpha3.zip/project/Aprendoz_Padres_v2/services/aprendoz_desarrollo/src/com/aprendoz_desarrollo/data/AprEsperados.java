
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprEsperados
 *  01/22/2014 15:41:29
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
