
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Salon
 *  01/22/2014 15:41:28
 * 
 */
public class Salon {

    private Integer idSalon;
    private String numeroSalon;

    public Integer getIdSalon() {
        return idSalon;
    }

    public void setIdSalon(Integer idSalon) {
        this.idSalon = idSalon;
    }

    public String getNumeroSalon() {
        return numeroSalon;
    }

    public void setNumeroSalon(String numeroSalon) {
        this.numeroSalon = numeroSalon;
    }

}
